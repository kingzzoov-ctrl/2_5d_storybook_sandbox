PRAGMA journal_mode = WAL;
PRAGMA synchronous = NORMAL;

CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    level INTEGER NOT NULL DEFAULT 1,
    exp INTEGER NOT NULL DEFAULT 0,
    hp INTEGER NOT NULL DEFAULT 100,
    max_hp INTEGER NOT NULL DEFAULT 100,
    equipment_json TEXT NOT NULL DEFAULT '{"weapon":711,"armor":724,"helm":616,"boots":620,"relic":731}',
    inventory_json TEXT NOT NULL DEFAULT '{"101":20,"106":10,"201":1,"218":1,"221":1,"222":1,"711":1}',
    dew_count INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS room_chunks (
    room_id TEXT NOT NULL,
    chunk_x INTEGER NOT NULL,
    chunk_y INTEGER NOT NULL,
    tiles_blob BLOB NOT NULL,
    entities_json TEXT NOT NULL DEFAULT '{}',
    updated_at INTEGER NOT NULL,
    PRIMARY KEY (room_id, chunk_x, chunk_y)
);

CREATE TABLE IF NOT EXISTS ai_alchemy_recipes (
    recipe_hash TEXT PRIMARY KEY,
    discoverer_name TEXT NOT NULL,
    item_name TEXT NOT NULL,
    item_category TEXT NOT NULL,
    llm_schema_json TEXT NOT NULL,
    craft_count INTEGER NOT NULL DEFAULT 1,
    created_at INTEGER NOT NULL
);
