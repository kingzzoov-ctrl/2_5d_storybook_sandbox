# 2.5D 精致绘本风·高自由度多人欢笑沙盒 工程文件包

## 目录结构说明
- `assets/atlas_sprites.png`：全量 358 项实体（320 项物品方块 + 6 大角色 + 24 种野生动物 + 8 大世界 Boss）的 64×64 绘本立牌精灵图集（20列 × 18行）。
- `assets/atlas_sprites.json`：标准 TexturePacker / PixiJS / Three.js 纹理坐标映射与锚点元数据文件。
- `assets/concept_sheets/`：5 张高清 2.5D 绘本折纸风设定原画大图（角色、8大Boss、24种野生生物、武器整蛊玩具、地形电路载具）。
- `shared/constants/items.ts`：全量 358 项实体的 TypeScript 强类型配置表（含配方、词条 Tags、价值分 V_i、配色与形状定义）。
- `shared/world/BitpackChunk.ts`：单区块 1KB 的 32-Bit `Uint32Array` 五层网格位压缩读写器。
- `shared/alchemy/AlchemyMathEngine.ts`：【万物奇想炼金炉】大模型结构化输出接口与五步确定性属性生成算法。
- `server/src/db/schema.sql`：适配 1GB 内存服务器的 SQLite WAL 模式建表脚本。
