// 32-Bit Voxel-Grid Bitpacking & BFS Dynamic Room Recognition Engine (1KB per 16x16 Chunk)
export class BitpackChunk {
  public static readonly SIZE = 16;
  public readonly data: Uint32Array;

  constructor(buffer?: ArrayBuffer) {
    this.data = buffer ? new Uint32Array(buffer) : new Uint32Array(256);
  }

  public static pack(z: number, base: number, floor: number, wire: number, objId: number, meta: number): number {
    return ((z & 0x3) | ((base & 0xF) << 2) | ((floor & 0x3F) << 6) | ((wire & 0xF) << 12) | ((objId & 0xFFF) << 16) | ((meta & 0xF) << 28)) >>> 0;
  }

  public static unpack(cell: number) {
    return {
      elevationZ: (cell & 0x3) - 1, // -1, 0, 1, 2
      baseTerrain: (cell >>> 2) & 0xF,
      floorTile: (cell >>> 6) & 0x3F,
      wireMask: (cell >>> 12) & 0xF,
      objectId: (cell >>> 16) & 0xFFF,
      meta: (cell >>> 28) & 0xF,
    };
  }
}
