// Auto-generated Full Registry of 358 Entities (320 Items/Blocks + 6 Classes + 24 Wildlife + 8 Bosses)
export interface GameEntityDef {
  id: number;
  name: string;
  category: string;
  subCategory: string;
  recipe: string;
  tags: string[];
  value: number;
  desc: string;
  color1: string;
  color2: string;
  shape: string;
}

export const MASTER_REGISTRY: Record<number, GameEntityDef> = {
  "101": {
    "id": 101,
    "name": "暖松原木",
    "category": "3.1 自然资源",
    "subCategory": "晨曦草甸砍伐",
    "recipe": "晨曦草甸砍伐",
    "tags": [
      "木材",
      "燃料",
      "长柄"
    ],
    "value": 10,
    "desc": "锯成木板、制作基础工具柄、篝火添柴",
    "color1": "#8D5B4C",
    "color2": "#D7B377",
    "shape": "log"
  },
  "102": {
    "id": 102,
    "name": "绯樱原木",
    "category": "3.1 自然资源",
    "subCategory": "绯樱高地合砍",
    "recipe": "绯樱高地合砍",
    "tags": [
      "木材",
      "芳香",
      "治愈"
    ],
    "value": 22,
    "desc": "制作日式障子门、樱花家具、治愈系法器",
    "color1": "#A65E6E",
    "color2": "#FFB7C5",
    "shape": "log"
  },
  "103": {
    "id": 103,
    "name": "翠玉青竹",
    "category": "3.1 自然资源",
    "subCategory": "绯樱高地竹林",
    "recipe": "绯樱高地竹林",
    "tags": [
      "木材",
      "弹性",
      "管状"
    ],
    "value": 20,
    "desc": "制作竹筒水车、吹箭筒、引水竹管、撑杆跳竹竿",
    "color1": "#58A65C",
    "color2": "#A8E6CF",
    "shape": "bamboo"
  },
  "104": {
    "id": 104,
    "name": "夜光菌木",
    "category": "3.1 自然资源",
    "subCategory": "萤光溶洞巨菇",
    "recipe": "萤光溶洞巨菇",
    "tags": [
      "木材",
      "发光",
      "魔导"
    ],
    "value": 28,
    "desc": "制作免通电自发光家具、法杖杆",
    "color1": "#4A47A3",
    "color2": "#70D6FF",
    "shape": "mushroom"
  },
  "105": {
    "id": 105,
    "name": "焦糖威化木",
    "category": "3.1 自然资源",
    "subCategory": "甜点奇境砍伐",
    "recipe": "甜点奇境砍伐",
    "tags": [
      "木材",
      "甜食",
      "诱饵"
    ],
    "value": 35,
    "desc": "建造糖果屋墙体、制作诱捕果冻怪的香甜武器",
    "color1": "#C68B59",
    "color2": "#F7D08A",
    "shape": "grid_block"
  },
  "106": {
    "id": 106,
    "name": "云母圆石",
    "category": "3.1 自然资源",
    "subCategory": "草甸河谷敲击",
    "recipe": "草甸河谷敲击",
    "tags": [
      "石材",
      "坚硬",
      "钝器"
    ],
    "value": 12,
    "desc": "铺设石板路、砌石墙、建造熔炉与石拱桥",
    "color1": "#7F8C8D",
    "color2": "#BDC3C7",
    "shape": "rock"
  },
  "107": {
    "id": 107,
    "name": "河畔红黏土",
    "category": "3.1 自然资源",
    "subCategory": "浅水河床挖掘",
    "recipe": "浅水河床挖掘",
    "tags": [
      "陶土",
      "可塑",
      "容器"
    ],
    "value": 15,
    "desc": "烧制红砖、屋顶红瓦、花盆、储物陶罐",
    "color1": "#C0564B",
    "color2": "#E28743",
    "shape": "clay"
  },
  "108": {
    "id": 108,
    "name": "琉璃石英砂",
    "category": "3.1 自然资源",
    "subCategory": "星沙绿洲挖掘",
    "recipe": "星沙绿洲挖掘",
    "tags": [
      "沙材",
      "透明",
      "折射"
    ],
    "value": 25,
    "desc": "烧制成全透明玻璃幕墙、天窗、光学棱镜",
    "color1": "#F4D06F",
    "color2": "#FFF8E7",
    "shape": "sand"
  },
  "109": {
    "id": 109,
    "name": "白玉温泉石",
    "category": "3.1 自然资源",
    "subCategory": "温泉眼周边开采",
    "recipe": "温泉眼周边开采",
    "tags": [
      "石材",
      "保温",
      "恢复"
    ],
    "value": 30,
    "desc": "砌筑人工温泉池壁（使普通水转化为温泉水）",
    "color1": "#E8EEF1",
    "color2": "#F7B2BD",
    "shape": "rock"
  },
  "110": {
    "id": 110,
    "name": "黑曜石块",
    "category": "3.1 自然资源",
    "subCategory": "水浇熔岩凝结",
    "recipe": "水浇熔岩凝结",
    "tags": [
      "石材",
      "抗爆",
      "锋利"
    ],
    "value": 55,
    "desc": "制作防爆墙、高暴击黑金武器、暗影传送门框",
    "color1": "#2C223E",
    "color2": "#9B5DE5",
    "shape": "crystal"
  },
  "111": {
    "id": 111,
    "name": "多孔浮石",
    "category": "3.1 自然资源",
    "subCategory": "温泉水触熔岩",
    "recipe": "温泉水触熔岩",
    "tags": [
      "石材",
      "浮力",
      "轻盈"
    ],
    "value": 40,
    "desc": "直接铺设在深水表面搭建漂浮水上平台",
    "color1": "#95A5A6",
    "color2": "#D5DBDB",
    "shape": "rock"
  },
  "112": {
    "id": 112,
    "name": "黄铜矿石",
    "category": "3.1 自然资源",
    "subCategory": "溶洞浅层开采",
    "recipe": "溶洞浅层开采",
    "tags": [
      "金属",
      "导电",
      "机械"
    ],
    "value": 25,
    "desc": "冶炼黄铜锭，制作机械臂、齿轮、火车零件",
    "color1": "#D4AC0D",
    "color2": "#F9E79F",
    "shape": "ore"
  },
  "113": {
    "id": 113,
    "name": "寒铁矿石",
    "category": "3.1 自然资源",
    "subCategory": "溶洞中层开采",
    "recipe": "溶洞中层开采",
    "tags": [
      "金属",
      "坚固",
      "锋利"
    ],
    "value": 40,
    "desc": "冶炼寒铁锭，制作铁砧、铁轨、重型护甲",
    "color1": "#5D6D7E",
    "color2": "#AEB6BF",
    "shape": "ore"
  },
  "114": {
    "id": 114,
    "name": "秘银矿石",
    "category": "3.1 自然资源",
    "subCategory": "溶洞深层开采",
    "recipe": "溶洞深层开采",
    "tags": [
      "金属",
      "轻盈",
      "魔导"
    ],
    "value": 70,
    "desc": "冶炼秘银锭，制作大师级武器、飞艇螺旋桨",
    "color1": "#48C9B0",
    "color2": "#D1F2EB",
    "shape": "ore"
  },
  "115": {
    "id": 115,
    "name": "曜金矿石",
    "category": "3.1 自然资源",
    "subCategory": "金字塔遗迹开采",
    "recipe": "金字塔遗迹开采",
    "tags": [
      "金属",
      "华贵",
      "暴击"
    ],
    "value": 85,
    "desc": "冶炼曜金锭，制作金皇冠、暴击饰品",
    "color1": "#F39C12",
    "color2": "#FEF9E7",
    "shape": "ore"
  },
  "116": {
    "id": 116,
    "name": "萤光魔晶簇",
    "category": "3.1 自然资源",
    "subCategory": "萤光溶洞晶脉",
    "recipe": "萤光溶洞晶脉",
    "tags": [
      "魔能",
      "发光",
      "导电"
    ],
    "value": 50,
    "desc": "提炼四色魔能电线、法杖核心、水车动力核",
    "color1": "#8E44AD",
    "color2": "#64FFDA",
    "shape": "crystal"
  },
  "117": {
    "id": 117,
    "name": "极光星辰碎片",
    "category": "3.1 自然资源",
    "subCategory": "夜晚云海坠落",
    "recipe": "夜晚云海坠落",
    "tags": [
      "魔能",
      "浮空",
      "陨星"
    ],
    "value": 120,
    "desc": "锻造毕业级星辰装备、点亮热气球引擎",
    "color1": "#FFD166",
    "color2": "#70D6FF",
    "shape": "star"
  },
  "118": {
    "id": 118,
    "name": "柔韧风草",
    "category": "3.1 自然资源",
    "subCategory": "草甸割高草丛",
    "recipe": "草甸割高草丛",
    "tags": [
      "纤维",
      "捆绑"
    ],
    "value": 8,
    "desc": "搓成草绳、编织草席、制作茅草屋顶",
    "color1": "#7CB518",
    "color2": "#C5E063",
    "shape": "herb"
  },
  "119": {
    "id": 119,
    "name": "云朵棉花",
    "category": "3.1 自然资源",
    "subCategory": "云海采集/剪羊毛",
    "recipe": "云海采集/剪羊毛",
    "tags": [
      "纤维",
      "蓬松",
      "浮力"
    ],
    "value": 25,
    "desc": "制作软床、飘飘气球、法师长袍、披风",
    "color1": "#FFFFFF",
    "color2": "#D6EAF8",
    "shape": "cloud"
  },
  "120": {
    "id": 120,
    "name": "幻彩蚕丝",
    "category": "3.1 自然资源",
    "subCategory": "果园桑树养蚕",
    "recipe": "果园桑树养蚕",
    "tags": [
      "纤维",
      "丝滑",
      "韧性"
    ],
    "value": 45,
    "desc": "织造高闪避轻甲、高级画布、热气球伞面",
    "color1": "#FF99C8",
    "color2": "#FCF6BD",
    "shape": "spool"
  },
  "121": {
    "id": 121,
    "name": "露水甜莓",
    "category": "3.1 自然资源",
    "subCategory": "草甸浆果丛采摘",
    "recipe": "草甸浆果丛采摘",
    "tags": [
      "水果",
      "香甜",
      "恢复"
    ],
    "value": 10,
    "desc": "食用回血、榨汁、驯服草甸小动物",
    "color1": "#E63946",
    "color2": "#FFB5A7",
    "shape": "berry"
  },
  "122": {
    "id": 122,
    "name": "金秋蜜桃",
    "category": "3.1 自然资源",
    "subCategory": "河谷桃树采摘",
    "recipe": "河谷桃树采摘",
    "tags": [
      "水果",
      "恢复",
      "护盾"
    ],
    "value": 18,
    "desc": "制作蜜桃派、驯服河狸木匠与温泉水豚",
    "color1": "#FF758F",
    "color2": "#FFE5EC",
    "shape": "peach"
  },
  "123": {
    "id": 123,
    "name": "黄金小麦",
    "category": "3.1 自然资源",
    "subCategory": "河谷耕地收获",
    "recipe": "河谷耕地收获",
    "tags": [
      "谷物",
      "饱腹"
    ],
    "value": 14,
    "desc": "磨制面粉、烤面包、驯服云朵绵羊与陆行鸟",
    "color1": "#F4A261",
    "color2": "#E9C46A",
    "shape": "wheat"
  },
  "124": {
    "id": 124,
    "name": "弹簧跳跳菇",
    "category": "3.1 自然资源",
    "subCategory": "溶洞与甜点采摘",
    "recipe": "溶洞与甜点采摘",
    "tags": [
      "菌类",
      "高弹",
      "击退"
    ],
    "value": 32,
    "desc": "合成弹射弹簧垫、打造充气玩具大锤",
    "color1": "#FF595E",
    "color2": "#FFCA3A",
    "shape": "mushroom"
  },
  "125": {
    "id": 125,
    "name": "滑溜香蕉",
    "category": "3.1 自然资源",
    "subCategory": "绿洲香蕉树采摘",
    "recipe": "绿洲香蕉树采摘",
    "tags": [
      "水果",
      "极滑",
      "摔跤"
    ],
    "value": 28,
    "desc": "吃完获香蕉皮，投入炼金炉赋予打滑词条",
    "color1": "#FFBE0B",
    "color2": "#FFF3B0",
    "shape": "banana"
  },
  "126": {
    "id": 126,
    "name": "爆裂火椒",
    "category": "3.1 自然资源",
    "subCategory": "绿洲耕种收获",
    "recipe": "绿洲耕种收获",
    "tags": [
      "蔬果",
      "辛辣",
      "爆炸"
    ],
    "value": 38,
    "desc": "制作定时痒痒炸弹果、火焰箭矢、喷火汤",
    "color1": "#D90429",
    "color2": "#FF9F1C",
    "shape": "chili"
  },
  "127": {
    "id": 127,
    "name": "幻彩变身菇",
    "category": "3.1 自然资源",
    "subCategory": "雨天森林刷新",
    "recipe": "雨天森林刷新",
    "tags": [
      "菌类",
      "变形",
      "致幻"
    ],
    "value": 50,
    "desc": "制作变身吹箭、投入炼金炉赋予命中变形",
    "color1": "#9B5DE5",
    "color2": "#00F5D4",
    "shape": "mushroom"
  },
  "128": {
    "id": 128,
    "name": "粘性皇家蜂蜜",
    "category": "3.1 自然资源",
    "subCategory": "果园野生蜂箱",
    "recipe": "果园野生蜂箱",
    "tags": [
      "甜食",
      "强粘性",
      "减速"
    ],
    "value": 42,
    "desc": "制作粘性减速地垫、蜂蜜罐投掷物",
    "color1": "#F77F00",
    "color2": "#FCBF49",
    "shape": "jar"
  },
  "129": {
    "id": 129,
    "name": "冰晶薄荷叶",
    "category": "3.1 自然资源",
    "subCategory": "云海边缘采集",
    "recipe": "云海边缘采集",
    "tags": [
      "草药",
      "冰冻",
      "寒冷"
    ],
    "value": 45,
    "desc": "制作冰霜雪球、冰冻箭矢、铺设镜面滑冰砖",
    "color1": "#00BBF9",
    "color2": "#E0FBFC",
    "shape": "herb"
  },
  "130": {
    "id": 130,
    "name": "梦境露水",
    "category": "3.1 自然资源",
    "subCategory": "打盹/摸头产出",
    "recipe": "打盹/摸头产出",
    "tags": [
      "精华",
      "催熟",
      "催化剂"
    ],
    "value": 60,
    "desc": "瞬间催熟作物、激活描图卷轴、炼金催化剂",
    "color1": "#4EA8DE",
    "color2": "#CAF0F8",
    "shape": "drop"
  },
  "151": {
    "id": 151,
    "name": "精刨松木板",
    "category": "3.2 加工材料",
    "subCategory": "木工切木机",
    "recipe": "暖松原木×1",
    "tags": [
      "木板",
      "建材"
    ],
    "value": 15,
    "desc": "建造木屋墙体、地板、木箱、基础木盾",
    "color1": "#B07D62",
    "color2": "#E6CCB2",
    "shape": "plank"
  },
  "152": {
    "id": 152,
    "name": "绯樱香木板",
    "category": "3.2 加工材料",
    "subCategory": "木工切木机",
    "recipe": "绯樱原木×1",
    "tags": [
      "木板",
      "芳香"
    ],
    "value": 30,
    "desc": "建造日式和风建筑、猎弓弓身、乐器共鸣箱",
    "color1": "#D88C9A",
    "color2": "#F2D0A9",
    "shape": "plank"
  },
  "153": {
    "id": 153,
    "name": "窑烧红砖块",
    "category": "3.2 加工材料",
    "subCategory": "铁匠高炉",
    "recipe": "河畔红黏土×2",
    "tags": [
      "砖块",
      "耐火"
    ],
    "value": 25,
    "desc": "砌筑红砖墙、壁炉、面包烤炉、拱桥桥墩",
    "color1": "#B23A48",
    "color2": "#FCB9B2",
    "shape": "brick"
  },
  "154": {
    "id": 154,
    "name": "全透琉璃板",
    "category": "3.2 加工材料",
    "subCategory": "铁匠高炉",
    "recipe": "琉璃石英砂×2",
    "tags": [
      "玻璃",
      "透明"
    ],
    "value": 35,
    "desc": "制作全透明玻璃幕墙、温室天窗、生态缸外壁",
    "color1": "#90E0EF",
    "color2": "#CAF0F8",
    "shape": "glass"
  },
  "155": {
    "id": 155,
    "name": "黄铜金属锭",
    "category": "3.2 加工材料",
    "subCategory": "铁匠高炉",
    "recipe": "黄铜矿×2+原木×1",
    "tags": [
      "金属",
      "导电"
    ],
    "value": 45,
    "desc": "锻造齿轮、导线扳手、黄铜武器、铜管乐器",
    "color1": "#E09F3E",
    "color2": "#FFF3B0",
    "shape": "ingot"
  },
  "156": {
    "id": 156,
    "name": "寒铁金属锭",
    "category": "3.2 加工材料",
    "subCategory": "铁匠高炉",
    "recipe": "寒铁矿×2+原木×1",
    "tags": [
      "金属",
      "坚固"
    ],
    "value": 65,
    "desc": "锻造铁轨、寒铁武器、重型锁子甲、飞索钩爪",
    "color1": "#5C677D",
    "color2": "#CBD5E1",
    "shape": "ingot"
  },
  "157": {
    "id": 157,
    "name": "秘银魔导锭",
    "category": "3.2 加工材料",
    "subCategory": "铁匠高炉",
    "recipe": "秘银矿×2+魔晶×1",
    "tags": [
      "金属",
      "魔导"
    ],
    "value": 110,
    "desc": "锻造秘银武器、机械臂、云海飞艇引擎",
    "color1": "#2EC4B6",
    "color2": "#CBF3F0",
    "shape": "ingot"
  },
  "158": {
    "id": 158,
    "name": "精密发条齿轮",
    "category": "3.2 加工材料",
    "subCategory": "铁砧工作台",
    "recipe": "黄铜金属锭×1",
    "tags": [
      "机械",
      "旋转"
    ],
    "value": 30,
    "desc": "组装定向传送带、360°旋转推杆、连弩机关",
    "color1": "#D4A373",
    "color2": "#FAEDCD",
    "shape": "gear"
  },
  "159": {
    "id": 159,
    "name": "四色魔能线芯",
    "category": "3.2 加工材料",
    "subCategory": "铁砧工作台",
    "recipe": "魔晶×1+黄铜锭×1",
    "tags": [
      "电路",
      "导电"
    ],
    "value": 20,
    "desc": "铺设地面下隐藏的红/蓝/黄/绿四色逻辑电路网",
    "color1": "#FF006E",
    "color2": "#3A86FF",
    "shape": "wire"
  },
  "160": {
    "id": 160,
    "name": "结实风草绳",
    "category": "3.2 加工材料",
    "subCategory": "手工/纺织机",
    "recipe": "柔韧风草×2",
    "tags": [
      "绳索",
      "捆绑"
    ],
    "value": 16,
    "desc": "制作吊桥、拔河麻绳、气球捆绳、弓弦",
    "color1": "#8A9A86",
    "color2": "#D4E09B",
    "shape": "spool"
  },
  "161": {
    "id": 161,
    "name": "蓬松云朵布",
    "category": "3.2 加工材料",
    "subCategory": "纺织机",
    "recipe": "云朵棉花×2",
    "tags": [
      "布料",
      "轻盈"
    ],
    "value": 40,
    "desc": "制作画布、地毯、沙发软垫、法师布甲",
    "color1": "#F8F9FA",
    "color2": "#BDE0FE",
    "shape": "cloth"
  },
  "162": {
    "id": 162,
    "name": "高弹果冻胶",
    "category": "3.2 加工材料",
    "subCategory": "炼金调色桶",
    "recipe": "跳跳菇×1+甜莓×1",
    "tags": [
      "凝胶",
      "高弹"
    ],
    "value": 45,
    "desc": "制作果冻蹦床砖、充气玩具、果冻足球内核",
    "color1": "#06D6A0",
    "color2": "#B8F2E6",
    "shape": "slime_ball"
  },
  "163": {
    "id": 163,
    "name": "麦香精面粉",
    "category": "3.2 加工材料",
    "subCategory": "水车磨坊",
    "recipe": "黄金小麦×2",
    "tags": [
      "食材",
      "烘焙"
    ],
    "value": 25,
    "desc": "制作面包、披萨饼底、果酱派、Boss召唤布丁",
    "color1": "#F5EBE0",
    "color2": "#E3D5CA",
    "shape": "bag"
  },
  "164": {
    "id": 164,
    "name": "甜莓浓缩果酱",
    "category": "3.2 加工材料",
    "subCategory": "果汁水车",
    "recipe": "露水甜莓×3",
    "tags": [
      "甜食",
      "果酱"
    ],
    "value": 32,
    "desc": "涂抹制作加速甜点、合成瞬回生命药水",
    "color1": "#E63946",
    "color2": "#FFCCD5",
    "shape": "jar"
  },
  "165": {
    "id": 165,
    "name": "陶瓷空药水瓶",
    "category": "3.2 加工材料",
    "subCategory": "铁匠高炉",
    "recipe": "琉璃石英砂×1",
    "tags": [
      "容器",
      "投掷"
    ],
    "value": 15,
    "desc": "灌装生命恢复药水、缩小/巨人药水、颜料水球",
    "color1": "#A8DADC",
    "color2": "#F1FAEE",
    "shape": "potion"
  },
  "166": {
    "id": 166,
    "name": "绯红植物染料",
    "category": "3.2 加工材料",
    "subCategory": "炼金调色桶",
    "recipe": "露水甜莓×2",
    "tags": [
      "染料",
      "红色"
    ],
    "value": 20,
    "desc": "供染色喷枪与16×16像素画架使用的红色颜料",
    "color1": "#EF233C",
    "color2": "#FF8FA3",
    "shape": "dye"
  },
  "167": {
    "id": 167,
    "name": "琥珀阳光染料",
    "category": "3.2 加工材料",
    "subCategory": "炼金调色桶",
    "recipe": "小麦×1+蜜桃×1",
    "tags": [
      "染料",
      "暖黄"
    ],
    "value": 24,
    "desc": "供染色喷枪与像素画架使用的暖黄/橙色颜料",
    "color1": "#FFB703",
    "color2": "#FFE5B4",
    "shape": "dye"
  },
  "168": {
    "id": 168,
    "name": "翡翠森林染料",
    "category": "3.2 加工材料",
    "subCategory": "炼金调色桶",
    "recipe": "风草×2+青竹×1",
    "tags": [
      "染料",
      "翠绿"
    ],
    "value": 24,
    "desc": "供染色喷枪与像素画架使用的翠绿色颜料",
    "color1": "#2A9D8F",
    "color2": "#A7F3D0",
    "shape": "dye"
  },
  "169": {
    "id": 169,
    "name": "星夜霓虹染料",
    "category": "3.2 加工材料",
    "subCategory": "炼金调色桶",
    "recipe": "魔晶×1+薄荷×1",
    "tags": [
      "染料",
      "发光"
    ],
    "value": 55,
    "desc": "带有夜间自发光效果的青蓝/紫罗兰荧光颜料",
    "color1": "#7209B7",
    "color2": "#4CC9F0",
    "shape": "dye"
  },
  "170": {
    "id": 170,
    "name": "空白描图纸卷",
    "category": "3.2 加工材料",
    "subCategory": "木工营造台",
    "recipe": "风草×3+面粉×1",
    "tags": [
      "卷轴",
      "蓝图"
    ],
    "value": 35,
    "desc": "结合梦境露水制作【魔法描图卷轴】保存建筑",
    "color1": "#F4F1DE",
    "color2": "#E07A5F",
    "shape": "scroll"
  },
  "201": {
    "id": 201,
    "name": "暖松石刃斧",
    "category": "3.3 生产工具",
    "subCategory": "通用/建筑",
    "recipe": "暖松原木×2+圆石×2",
    "tags": [
      "工具",
      "伐木"
    ],
    "value": 30,
    "desc": "基础伐木与拆木墙；多人围砍激活N人阶梯暴击",
    "color1": "#8D5B4C",
    "color2": "#95A5A6",
    "shape": "axe"
  },
  "202": {
    "id": 202,
    "name": "秘银旋风斧",
    "category": "3.3 生产工具",
    "subCategory": "建筑师",
    "recipe": "秘银锭×2+樱木板×2",
    "tags": [
      "工具",
      "旋风"
    ],
    "value": 140,
    "desc": "蓄力1秒旋转挥砍周围3×3格内所有树木与木桶",
    "color1": "#2EC4B6",
    "color2": "#FFB7C5",
    "shape": "axe"
  },
  "203": {
    "id": 203,
    "name": "矿工十字石镐",
    "category": "3.3 生产工具",
    "subCategory": "通用/探险",
    "recipe": "暖松原木×2+圆石×3",
    "tags": [
      "工具",
      "采矿"
    ],
    "value": 32,
    "desc": "基础采矿与拆石墙；可在地下溶洞敲穿软岩壁",
    "color1": "#8D5B4C",
    "color2": "#7F8C8D",
    "shape": "pickaxe"
  },
  "204": {
    "id": 204,
    "name": "黑金爆破冲击镐",
    "category": "3.3 生产工具",
    "subCategory": "探险家",
    "recipe": "黑曜石×2+寒铁锭×2",
    "tags": [
      "工具",
      "破甲"
    ],
    "value": 150,
    "desc": "每次挥击产生震波敲击1×3矿脉，一击敲碎晶甲护盾",
    "color1": "#2C223E",
    "color2": "#FF9F1C",
    "shape": "pickaxe"
  },
  "205": {
    "id": 205,
    "name": "改地水渠木铲",
    "category": "3.3 生产工具",
    "subCategory": "园艺师",
    "recipe": "暖松原木×2+黄铜锭×1",
    "tags": [
      "工具",
      "挖渠"
    ],
    "value": 50,
    "desc": "挖低Z0草地形成Z-1引水渠，或铲出草皮移植",
    "color1": "#D4AC0D",
    "color2": "#8D5B4C",
    "shape": "shovel"
  },
  "206": {
    "id": 206,
    "name": "造山填海泥瓦刀",
    "category": "3.3 生产工具",
    "subCategory": "建筑师",
    "recipe": "寒铁锭×2+红黏土×4",
    "tags": [
      "工具",
      "堆高"
    ],
    "value": 85,
    "desc": "消耗泥土石块一键将2×2平地抬升为Z1/Z2高台",
    "color1": "#5C677D",
    "color2": "#E28743",
    "shape": "shovel"
  },
  "207": {
    "id": 207,
    "name": "四色电路扳手",
    "category": "3.3 生产工具",
    "subCategory": "工程师",
    "recipe": "黄铜锭×2+魔能线芯×2",
    "tags": [
      "工具",
      "电路"
    ],
    "value": 90,
    "desc": "展开地下暗线视图，拖拽铺设四色电线与调音符",
    "color1": "#E09F3E",
    "color2": "#3A86FF",
    "shape": "wrench"
  },
  "208": {
    "id": 208,
    "name": "魔法描图卷轴",
    "category": "3.3 生产工具",
    "subCategory": "建筑师",
    "recipe": "描图纸×1+梦境露水×2",
    "tags": [
      "蓝图",
      "复制"
    ],
    "value": 120,
    "desc": "框选16×16自建房屋生成施工虚影供全房飞砖接力",
    "color1": "#7209B7",
    "color2": "#F4F1DE",
    "shape": "scroll"
  },
  "209": {
    "id": 209,
    "name": "32色气压染色枪",
    "category": "3.3 生产工具",
    "subCategory": "画师",
    "recipe": "黄铜锭×1+空药水瓶×2",
    "tags": [
      "工具",
      "涂色"
    ],
    "value": 75,
    "desc": "对准墙体、屋顶、家具、宠物甚至队友喷涂改色",
    "color1": "#FF006E",
    "color2": "#FFBE0B",
    "shape": "gun"
  },
  "210": {
    "id": 210,
    "name": "园艺十字嫁接剪",
    "category": "3.3 生产工具",
    "subCategory": "园艺师",
    "recipe": "寒铁锭×2+翠玉青竹×1",
    "tags": [
      "工具",
      "杂交"
    ],
    "value": 80,
    "desc": "对相邻两株不同颜色花卉使用，必出稀有变异种子",
    "color1": "#58A65C",
    "color2": "#CBD5E1",
    "shape": "scissors"
  },
  "211": {
    "id": 211,
    "name": "波波森灵指挥笛",
    "category": "3.3 生产工具",
    "subCategory": "园艺师",
    "recipe": "翠玉青竹×2+魔晶簇×1",
    "tags": [
      "工具",
      "召唤"
    ],
    "value": 95,
    "desc": "吹奏召唤波波森灵或已驯服动物跟随助战/收菜",
    "color1": "#58A65C",
    "color2": "#64FFDA",
    "shape": "flute"
  },
  "212": {
    "id": 212,
    "name": "欢宴翻炒大铁铲",
    "category": "3.3 生产工具",
    "subCategory": "大厨",
    "recipe": "寒铁锭×2+暖松原木×1",
    "tags": [
      "工具",
      "烹饪"
    ],
    "value": 78,
    "desc": "在大汤锅或高炉旁挥动瞬间降温灭火并加料理词条",
    "color1": "#5C677D",
    "color2": "#E07A5F",
    "shape": "spatula"
  },
  "213": {
    "id": 213,
    "name": "弹性捕虫扑网",
    "category": "3.3 生产工具",
    "subCategory": "通用/休闲",
    "recipe": "翠玉青竹×2+风草绳×2",
    "tags": [
      "工具",
      "捕捉"
    ],
    "value": 45,
    "desc": "捕捉森林发光萤火虫、蝴蝶、蜜蜂装入生态瓶",
    "color1": "#A8E6CF",
    "color2": "#FFFFFF",
    "shape": "net"
  },
  "214": {
    "id": 214,
    "name": "浮标弹射钓鱼竿",
    "category": "3.3 生产工具",
    "subCategory": "通用/休闲",
    "recipe": "翠玉青竹×3+幻彩蚕丝×2",
    "tags": [
      "工具",
      "垂钓"
    ],
    "value": 68,
    "desc": "在小河、温泉或云海垂钓特产鱼类与沉底装备宝箱",
    "color1": "#58A65C",
    "color2": "#FF595E",
    "shape": "rod"
  },
  "215": {
    "id": 215,
    "name": "地下遗迹探测仪",
    "category": "3.3 生产工具",
    "subCategory": "探险家",
    "recipe": "黄铜锭×2+魔晶簇×2",
    "tags": [
      "工具",
      "探测"
    ],
    "value": 110,
    "desc": "根据距离隐藏地窖或Boss祭坛远近发出滴滴声光提示",
    "color1": "#E09F3E",
    "color2": "#00F5D4",
    "shape": "compass"
  },
  "216": {
    "id": 216,
    "name": "多人合力抬物扁担",
    "category": "3.3 生产工具",
    "subCategory": "通用/合作",
    "recipe": "翠玉青竹×4+风草绳×2",
    "tags": [
      "合作",
      "搬运"
    ],
    "value": 60,
    "desc": "2~4人装备后可抬起Boss巨型金箱或整座木屋搬迁",
    "color1": "#D4A373",
    "color2": "#58A65C",
    "shape": "staff"
  },
  "217": {
    "id": 217,
    "name": "强力磁吸拾取器",
    "category": "3.3 生产工具",
    "subCategory": "工程师",
    "recipe": "黑曜石×1+黄铜锭×2",
    "tags": [
      "工具",
      "磁吸"
    ],
    "value": 115,
    "desc": "自动将周围6格内散落的木头、矿石与经验球吸入背包",
    "color1": "#EF233C",
    "color2": "#3A86FF",
    "shape": "magnet"
  },
  "218": {
    "id": 218,
    "name": "工程安全帽(和平盾)",
    "category": "3.3 生产工具",
    "subCategory": "通用防坑",
    "recipe": "初始背包常驻开关",
    "tags": [
      "护盾",
      "防坑"
    ],
    "value": 50,
    "desc": "开启后100%免疫队友举起、大锤击退与香蕉皮暗算",
    "color1": "#FFBE0B",
    "color2": "#FB8500",
    "shape": "helmet"
  },
  "221": {
    "id": 221,
    "name": "大力士举重手套",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "举投/叠罗汉",
    "recipe": "云朵布×2+风草绳×2",
    "tags": [
      "举投",
      "叠罗汉"
    ],
    "value": 65,
    "desc": "隔河抛接原木、4人叠罗汉，或把钓鱼打盹队友举起扔进河里",
    "color1": "#FF595E",
    "color2": "#FFFFFF",
    "shape": "glove"
  },
  "222": {
    "id": 222,
    "name": "充气玩具大锤",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "物理击飞",
    "recipe": "果冻胶×2+云朵布×2",
    "tags": [
      "高弹",
      "击退"
    ],
    "value": 70,
    "desc": "0伤害啾啾声，施加8格/秒击退冲量，可反抽穿山甲或锤飞队友",
    "color1": "#EF233C",
    "color2": "#FFBE0B",
    "shape": "hammer"
  },
  "223": {
    "id": 223,
    "name": "伸缩弹簧拳击套",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "远程推人",
    "recipe": "发条齿轮×2+跳跳菇×2",
    "tags": [
      "弹簧",
      "推人"
    ],
    "value": 85,
    "desc": "直线弹出4格远弹簧大拳头，隔河把对岸损友一拳顶下水",
    "color1": "#D90429",
    "color2": "#ADB5BD",
    "shape": "glove"
  },
  "224": {
    "id": 224,
    "name": "灵巧飞索钩爪",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "抓取/位移",
    "recipe": "寒铁锭×2+风草绳×3",
    "tags": [
      "飞索",
      "抓取"
    ],
    "value": 95,
    "desc": "勾住树桩跨河、勾住云鲸登背，或把抢到皇冠的朋友拽到面前",
    "color1": "#5C677D",
    "color2": "#D4A373",
    "shape": "hook"
  },
  "225": {
    "id": 225,
    "name": "滑溜溜香蕉皮",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "场地陷阱",
    "recipe": "吃掉滑溜香蕉获得",
    "tags": [
      "极滑",
      "摔跤"
    ],
    "value": 30,
    "desc": "踩中的队友或冲锋Boss立刻锁定方向极速打滑5格撞墙眩晕",
    "color1": "#FFBE0B",
    "color2": "#FB8500",
    "shape": "banana"
  },
  "226": {
    "id": 226,
    "name": "飘飘气球捆绳",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "浮空整蛊",
    "recipe": "云朵布×2+风草绳×1",
    "tags": [
      "浮力",
      "升空"
    ],
    "value": 55,
    "desc": "绑在近战怪或队友背上使其飘到Z=2高空手脚乱蹬",
    "color1": "#FF006E",
    "color2": "#00BBF9",
    "shape": "balloon"
  },
  "227": {
    "id": 227,
    "name": "泡泡连发水枪",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "救火/困人",
    "recipe": "青竹×2+果冻胶×1",
    "tags": [
      "流体",
      "泡泡"
    ],
    "value": 68,
    "desc": "扑灭高炉火苗、浇灭熔岩火灵护盾，连射队友3发装进大泡泡",
    "color1": "#06D6A0",
    "color2": "#4CC9F0",
    "shape": "gun"
  },
  "228": {
    "id": 228,
    "name": "定时痒痒炸弹果",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "抛接/破盾",
    "recipe": "爆裂火椒×2+红黏土×1",
    "tags": [
      "爆炸",
      "破甲"
    ],
    "value": 75,
    "desc": "3秒倒计时可击鼓传花互扔，扔进果冻王嘴里直接炸晕破防",
    "color1": "#D90429",
    "color2": "#FFBE0B",
    "shape": "bomb"
  },
  "229": {
    "id": 229,
    "name": "幻彩变身吹箭",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "变形控制",
    "recipe": "青竹×1+幻彩变身菇×1",
    "tags": [
      "变形",
      "软控"
    ],
    "value": 80,
    "desc": "吹中精英怪或队友使其变成咯咯叫的小肥鸡或小绵羊10秒",
    "color1": "#9B5DE5",
    "color2": "#58A65C",
    "shape": "flute"
  },
  "230": {
    "id": 230,
    "name": "缩小蚂蚁药水",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "体型整蛊",
    "recipe": "空药水瓶×1+魔晶簇×1",
    "tags": [
      "缩小",
      "极速"
    ],
    "value": 70,
    "desc": "角色或怪物缩小为0.3倍，移速暴增且能钻进隐藏遗迹洞口",
    "color1": "#00BBF9",
    "color2": "#CAF0F8",
    "shape": "potion"
  },
  "231": {
    "id": 231,
    "name": "进击巨人药水",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "体型爆发",
    "recipe": "空药水瓶×1+跳跳菇×2",
    "tags": [
      "巨大",
      "霸体"
    ],
    "value": 85,
    "desc": "角色体积放大2.0倍，生命与冲击力翻倍，可同时举起2名队友",
    "color1": "#FF006E",
    "color2": "#FFBE0B",
    "shape": "potion"
  },
  "232": {
    "id": 232,
    "name": "强力粘性蜂蜜罐",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "减速控制",
    "recipe": "皇家蜂蜜×2+红黏土×1",
    "tags": [
      "强粘",
      "减速"
    ],
    "value": 72,
    "desc": "砸碎形成3×3蜂蜜滩，减缓高速Boss、河狸或对手70%移速",
    "color1": "#F77F00",
    "color2": "#FCBF49",
    "shape": "jar"
  },
  "233": {
    "id": 233,
    "name": "极寒冰霜雪球",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "冰冻滑行",
    "recipe": "冰晶薄荷×2+梦境露水×1",
    "tags": [
      "冰冻",
      "冰壶"
    ],
    "value": 80,
    "desc": "将怪物或队友冻成冰雕3秒，用大锤敲击可像冰壶一样滑出撞人",
    "color1": "#4CC9F0",
    "color2": "#FFFFFF",
    "shape": "snowball"
  },
  "234": {
    "id": 234,
    "name": "便携弹簧跳板",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "垫脚/暗算",
    "recipe": "松木板×2+跳跳菇×2",
    "tags": [
      "高弹",
      "跳板"
    ],
    "value": 65,
    "desc": "随时丢脚下跳上高台躲震地波，或丢在冲刺队友面前反向弹回",
    "color1": "#FF595E",
    "color2": "#ADB5BD",
    "shape": "pad"
  },
  "235": {
    "id": 235,
    "name": "伪装恶作剧宝箱",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "惊喜整蛊",
    "recipe": "松木板×4+弹簧拳套×1",
    "tags": [
      "伪装",
      "击退"
    ],
    "value": 90,
    "desc": "外观与金箱子一致，朋友或哥布林打开时弹出大拳套揍飞3格",
    "color1": "#D4AC0D",
    "color2": "#EF233C",
    "shape": "chest"
  },
  "236": {
    "id": 236,
    "name": "臭鼬彩虹屁坐垫",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "家具整蛊",
    "recipe": "果冻胶×2+爆裂火椒×1",
    "tags": [
      "彩虹屁",
      "弹射"
    ],
    "value": 75,
    "desc": "偷放在餐厅椅子上，朋友坐上去发出噗声并被彩虹烟雾弹射半空",
    "color1": "#FF99C8",
    "color2": "#7209B7",
    "shape": "pad"
  },
  "237": {
    "id": 237,
    "name": "七彩颜料水球",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "涂色/致盲",
    "recipe": "空药水瓶×1+任意染料×1",
    "tags": [
      "涂色",
      "致盲"
    ],
    "value": 45,
    "desc": "爆开将3×3地面和队友染成彩色，砸中Boss眼睛使其攻击偏离",
    "color1": "#FF006E",
    "color2": "#06D6A0",
    "shape": "balloon"
  },
  "238": {
    "id": 238,
    "name": "撑杆跳高青竹竿",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "跨越地形",
    "recipe": "翠玉青竹×3+风草绳×1",
    "tags": [
      "跳跃",
      "跨越"
    ],
    "value": 58,
    "desc": "助跑撑杆越过4格宽河流或激光网，前面有人直接将其撞倒",
    "color1": "#58A65C",
    "color2": "#E9C46A",
    "shape": "staff"
  },
  "239": {
    "id": 239,
    "name": "竹蜻蜓飞行草帽",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "短暂滞空",
    "recipe": "翠玉青竹×2+柔韧风草×3",
    "tags": [
      "飞行",
      "草帽"
    ],
    "value": 66,
    "desc": "戴在头上连按跳跃键慢速飞越深渊，容易被朋友用水枪打下来",
    "color1": "#F4A261",
    "color2": "#58A65C",
    "shape": "helmet"
  },
  "240": {
    "id": 240,
    "name": "回旋木飞镖",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "远程拉怪",
    "recipe": "绯樱香木板×2",
    "tags": [
      "回旋",
      "投掷"
    ],
    "value": 52,
    "desc": "扔出打落果子、触发远处拉杆或打掉队友帽子后飞回手中",
    "color1": "#D88C9A",
    "color2": "#F4D06F",
    "shape": "boomerang"
  },
  "241": {
    "id": 241,
    "name": "双向拔河大麻绳",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "团队角力",
    "recipe": "结实风草绳×6",
    "tags": [
      "拔河",
      "角力"
    ],
    "value": 70,
    "desc": "好友拔河比赛，或多人套住沙暴法老蝎尾针将其硬生生拽出沙地",
    "color1": "#C68B59",
    "color2": "#E6CCB2",
    "shape": "spool"
  },
  "242": {
    "id": 242,
    "name": "大声公扩音喇叭",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "嘲讽/唤醒",
    "recipe": "黄铜锭×2+魔晶簇×1",
    "tags": [
      "声波",
      "嘲讽"
    ],
    "value": 88,
    "desc": "放大聊天文字气泡3倍，震醒打盹队友并强制吸引8格怪物仇恨",
    "color1": "#EF233C",
    "color2": "#FFFFFF",
    "shape": "horn"
  },
  "243": {
    "id": 243,
    "name": "引雷铁锅头盔",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "雷雨导电",
    "recipe": "寒铁金属锭×3",
    "tags": [
      "引雷",
      "导电"
    ],
    "value": 92,
    "desc": "雷雨天吸引闪电劈下麻痹周围3格怪物，自己变成爆炸头狂奔",
    "color1": "#495057",
    "color2": "#FFBE0B",
    "shape": "helmet"
  },
  "244": {
    "id": 244,
    "name": "果冻怪伪装壳",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "潜行接近",
    "recipe": "果冻胶×3+翡翠染料×1",
    "tags": [
      "潜行",
      "伪装"
    ],
    "value": 85,
    "desc": "套在身上变成绿色果冻怪，野怪不主动打你，可摸到Boss身后",
    "color1": "#06D6A0",
    "color2": "#118AB2",
    "shape": "helmet"
  },
  "245": {
    "id": 245,
    "name": "手持庆典烟花筒",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "氛围/惊吓",
    "recipe": "青竹×1+火椒×1+染料×1",
    "tags": [
      "烟花",
      "闪光"
    ],
    "value": 60,
    "desc": "边跑边向天空发射心形与像素图案烟花，吓退夜间暗影小怪",
    "color1": "#E63946",
    "color2": "#FFD166",
    "shape": "bamboo"
  },
  "246": {
    "id": 246,
    "name": "阳光尤克里里",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "战歌乐器",
    "recipe": "樱木板×2+幻彩蚕丝×2",
    "tags": [
      "乐器",
      "治愈"
    ],
    "value": 85,
    "desc": "演奏时为周围6格内队友提供每秒+5 HP持续生命恢复光环",
    "color1": "#E07A5F",
    "color2": "#F4F1DE",
    "shape": "instrument"
  },
  "247": {
    "id": 247,
    "name": "微风手风琴",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "战歌乐器",
    "recipe": "松木板×2+云朵布×2",
    "tags": [
      "乐器",
      "急速"
    ],
    "value": 85,
    "desc": "演奏时让周围队友采集效率与技能冷却缩减+20%",
    "color1": "#2A9D8F",
    "color2": "#FFFFFF",
    "shape": "instrument"
  },
  "248": {
    "id": 248,
    "name": "星光卡林巴琴",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "战歌乐器",
    "recipe": "夜光菌木×2+寒铁锭×1",
    "tags": [
      "乐器",
      "护盾"
    ],
    "value": 90,
    "desc": "演奏时为周围队友附加夜间照明与魔法抗性护盾",
    "color1": "#4A47A3",
    "color2": "#70D6FF",
    "shape": "instrument"
  },
  "249": {
    "id": 249,
    "name": "行进小军鼓",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "战歌乐器",
    "recipe": "暖松原木×2+风草绳×2",
    "tags": [
      "乐器",
      "进军"
    ],
    "value": 80,
    "desc": "边走边敲鼓，使身后跟随的队友排成整齐队列且移速攻速+25%",
    "color1": "#E63946",
    "color2": "#F4D06F",
    "shape": "drum"
  },
  "250": {
    "id": 250,
    "name": "翠玉竹长笛",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "驯兽乐器",
    "recipe": "翠玉青竹×3",
    "tags": [
      "乐器",
      "驯兽"
    ],
    "value": 75,
    "desc": "吹奏安抚狂暴的野生动物，使其进入可喂食驯化状态",
    "color1": "#58A65C",
    "color2": "#A8E6CF",
    "shape": "flute"
  },
  "251": {
    "id": 251,
    "name": "黄金凯旋小号",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "破隐乐器",
    "recipe": "黄铜金属锭×3",
    "tags": [
      "乐器",
      "破隐"
    ],
    "value": 105,
    "desc": "音波可直接震散千年妖狐Boss的假分身，并为全队+15%暴击率",
    "color1": "#F39C12",
    "color2": "#FEF9E7",
    "shape": "horn"
  },
  "252": {
    "id": 252,
    "name": "醇厚大提琴",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "控制乐器",
    "recipe": "樱木板×4+幻彩蚕丝×3",
    "tags": [
      "乐器",
      "减速"
    ],
    "value": 115,
    "desc": "低沉音波让周围敌对怪物的移动与攻击速度降低30%",
    "color1": "#8D5B4C",
    "color2": "#F2D0A9",
    "shape": "instrument"
  },
  "253": {
    "id": 253,
    "name": "叮当三角铁",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "集结信号",
    "recipe": "寒铁金属锭×2",
    "tags": [
      "乐器",
      "集结"
    ],
    "value": 65,
    "desc": "敲响后在小地图向全房队友发送高亮集结信号与清脆音波",
    "color1": "#ADB5BD",
    "color2": "#FFFFFF",
    "shape": "triangle"
  },
  "254": {
    "id": 254,
    "name": "魔能电音键盘",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "雷电战歌",
    "recipe": "秘银锭×2+魔能线芯×4",
    "tags": [
      "乐器",
      "感电"
    ],
    "value": 145,
    "desc": "演奏时队友的普通攻击附带连锁小闪电特效",
    "color1": "#7209B7",
    "color2": "#00F5D4",
    "shape": "instrument"
  },
  "255": {
    "id": 255,
    "name": "裁判金哨子",
    "category": "3.4 互坑玩具与乐器",
    "subCategory": "竞技控制",
    "recipe": "黄铜锭×1+风草绳×1",
    "tags": [
      "竞技",
      "召集"
    ],
    "value": 60,
    "desc": "吹响后立即在当前位置召集全房玩家开启造桥跑酷或抢皇冠赛",
    "color1": "#FFD166",
    "color2": "#EF233C",
    "shape": "horn"
  },
  "301": {
    "id": 301,
    "name": "肥沃农田耕地",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.75 / 移速100%",
    "recipe": "锄头开垦草地",
    "tags": [
      "地砖",
      "农业"
    ],
    "value": 10,
    "desc": "靠近水源3格内自动变为深色湿润耕地，作物生长加快",
    "color1": "#6F4E37",
    "color2": "#8A5A44",
    "shape": "tile"
  },
  "302": {
    "id": 302,
    "name": "青苔鹅卵石径",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.75 / 移速115%",
    "recipe": "云母圆石×1",
    "tags": [
      "地砖",
      "道路"
    ],
    "value": 12,
    "desc": "基础园林小路，自动根据相邻小路平滑拼接边缘",
    "color1": "#7F8C8D",
    "color2": "#58A65C",
    "shape": "tile"
  },
  "303": {
    "id": 303,
    "name": "暖松人字木地板",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.75 / 移速110%",
    "recipe": "精刨松木板×1",
    "tags": [
      "地砖",
      "室内"
    ],
    "value": 15,
    "desc": "温馨室内基础木地板，踩踏发出柔和木板声",
    "color1": "#B07D62",
    "color2": "#D4A373",
    "shape": "tile"
  },
  "304": {
    "id": 304,
    "name": "绯樱榻榻米席",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.75 / 移速110%",
    "recipe": "绯樱木板×1+风草×1",
    "tags": [
      "地砖",
      "和风"
    ],
    "value": 25,
    "desc": "和风室内铺装，在上面坐下打盹回血与攒露水速度额外+20%",
    "color1": "#C5E063",
    "color2": "#D88C9A",
    "shape": "tile"
  },
  "305": {
    "id": 305,
    "name": "复古红砖广场砖",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.75 / 移速115%",
    "recipe": "窑烧红砖块×1",
    "tags": [
      "地砖",
      "广场"
    ],
    "value": 20,
    "desc": "适合铺设城镇中心广场与集市街道",
    "color1": "#B23A48",
    "color2": "#E28743",
    "shape": "tile"
  },
  "306": {
    "id": 306,
    "name": "纯白大理石砖",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.78 / 移速115%",
    "recipe": "白玉温泉石×1",
    "tags": [
      "地砖",
      "高雅"
    ],
    "value": 28,
    "desc": "高雅画廊与圣殿地面，反光柔和",
    "color1": "#F8F9FA",
    "color2": "#DEE2E6",
    "shape": "tile"
  },
  "307": {
    "id": 307,
    "name": "黑白国际象棋砖",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.75 / 移速110%",
    "recipe": "圆石×1+黑曜石×1",
    "tags": [
      "地砖",
      "棋盘"
    ],
    "value": 35,
    "desc": "交替铺设可直接在地上和朋友用棋子雕塑下真人五子棋/象棋",
    "color1": "#212529",
    "color2": "#F8F9FA",
    "shape": "grid_block"
  },
  "308": {
    "id": 308,
    "name": "樱花花瓣地毯",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.75 / 移速110%",
    "recipe": "绯樱原木×1+云朵布×1",
    "tags": [
      "地砖",
      "花瓣"
    ],
    "value": 32,
    "desc": "走过时会惊起一串随风飘散的粉红花瓣粒子",
    "color1": "#FFB7C5",
    "color2": "#FFE5EC",
    "shape": "tile"
  },
  "309": {
    "id": 309,
    "name": "萤光星光夜路砖",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.75 / 移速115%",
    "recipe": "圆石×1+魔晶簇×1",
    "tags": [
      "地砖",
      "发光"
    ],
    "value": 40,
    "desc": "夜晚自动发出柔和蓝紫微光并阻止敌对野怪在上面刷新",
    "color1": "#3A0CA3",
    "color2": "#4CC9F0",
    "shape": "tile"
  },
  "310": {
    "id": 310,
    "name": "水上浮木栈桥",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.75 / 移速110%",
    "recipe": "松木板×1+风草绳×1",
    "tags": [
      "地砖",
      "跨水"
    ],
    "value": 22,
    "desc": "可直接铺设在Z=-1的河流与湖面上，架设跨水通道",
    "color1": "#8D5B4C",
    "color2": "#4EA8DE",
    "shape": "plank"
  },
  "311": {
    "id": 311,
    "name": "华夫威化饼干砖",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.75 / 移速110%",
    "recipe": "焦糖威化木×1",
    "tags": [
      "地砖",
      "甜点"
    ],
    "value": 30,
    "desc": "甜点风格地板，搭配巧克力墙使用",
    "color1": "#E09F3E",
    "color2": "#F7D08A",
    "shape": "grid_block"
  },
  "312": {
    "id": 312,
    "name": "绿茵足球场草皮",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.76 / 移速115%",
    "recipe": "风草×2+云朵布×1",
    "tags": [
      "地砖",
      "球场"
    ],
    "value": 25,
    "desc": "带有清晰的白色边线与中圈纹理，专为自建4v4球场设计",
    "color1": "#38B000",
    "color2": "#FFFFFF",
    "shape": "tile"
  },
  "313": {
    "id": 313,
    "name": "塑胶跑道计速砖",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.72 / 移速125%",
    "recipe": "红黏土×1+果冻胶×1",
    "tags": [
      "地砖",
      "竞速"
    ],
    "value": 30,
    "desc": "带有白色跑道线，供玩家铺设环岛马拉松与风筝Boss跑道",
    "color1": "#D90429",
    "color2": "#FFFFFF",
    "shape": "tile"
  },
  "314": {
    "id": 314,
    "name": "自定义像素地毯",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.75 / 移速110%",
    "recipe": "云朵布×1+任意染料×1",
    "tags": [
      "地砖",
      "UGC"
    ],
    "value": 35,
    "desc": "直接渲染玩家在16×16像素画架上手绘的图案，支持无缝拼图",
    "color1": "#FF006E",
    "color2": "#FFBE0B",
    "shape": "grid_block"
  },
  "315": {
    "id": 315,
    "name": "镜面极滑冰砖",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.98 / 移速130%",
    "recipe": "冰晶薄荷×1+浅水",
    "tags": [
      "机关砖",
      "极滑"
    ],
    "value": 45,
    "desc": "极度打滑！把冲锋野猪或晶甲巨蟹引上冰砖会刹不住车撞墙破甲",
    "color1": "#90E0EF",
    "color2": "#FFFFFF",
    "shape": "ice"
  },
  "316": {
    "id": 316,
    "name": "紫泥减速沼泽砖",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.40 / 移速45%",
    "recipe": "红黏土×1+变身菇×1",
    "tags": [
      "机关砖",
      "减速"
    ],
    "value": 42,
    "desc": "踩上去深陷泥潭寸步难行且无法跳跃，铺在祭坛外围限制近战怪",
    "color1": "#5A189A",
    "color2": "#9D4EDD",
    "shape": "tile"
  },
  "317": {
    "id": 317,
    "name": "单向狂飙加速带",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.85 / 移速200%",
    "recipe": "黄铜锭×1+发条齿轮×1",
    "tags": [
      "机关砖",
      "推力"
    ],
    "value": 55,
    "desc": "地面有流动金色箭头，踩上瞬间沿箭头方向施加10格/秒推力",
    "color1": "#495057",
    "color2": "#FFBE0B",
    "shape": "belt"
  },
  "318": {
    "id": 318,
    "name": "高弹果冻蹦床砖",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.80 / 弹跳Z=2",
    "recipe": "高弹果冻胶×2",
    "tags": [
      "机关砖",
      "高弹"
    ],
    "value": 50,
    "desc": "垂直弹跳直达Z=2，且能将姜饼巨魔Boss砸下的糖球原路反弹砸脸",
    "color1": "#FF6B6B",
    "color2": "#FFE66D",
    "shape": "pad"
  },
  "319": {
    "id": 319,
    "name": "伪装落穴草席",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.75 / 0.4s塌陷",
    "recipe": "风草×2+松木板×1",
    "tags": [
      "机关砖",
      "陷阱"
    ],
    "value": 38,
    "desc": "玩家或野怪踩上去0.4秒后咔嚓碎裂掉进下方水沟或捕兽坑",
    "color1": "#7CB518",
    "color2": "#6F4E37",
    "shape": "tile"
  },
  "320": {
    "id": 320,
    "name": "炙热烫脚火炭砖",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.75 / 移速135%",
    "recipe": "圆石×1+爆裂火椒×1",
    "tags": [
      "机关砖",
      "灼烧"
    ],
    "value": 48,
    "desc": "队友踩上捂屁股狂跳；野生怪物踩上每秒受到15点灼烧伤害",
    "color1": "#370617",
    "color2": "#F48C06",
    "shape": "tile"
  },
  "321": {
    "id": 321,
    "name": "眩晕旋转圆盘砖",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.80 / 旋转180°",
    "recipe": "发条齿轮×2+圆石×1",
    "tags": [
      "机关砖",
      "转向"
    ],
    "value": 52,
    "desc": "每秒自动将上方角色或怪物的朝向旋转180°，让怪物打偏攻击",
    "color1": "#4361EE",
    "color2": "#4CC9F0",
    "shape": "gear"
  },
  "322": {
    "id": 322,
    "name": "强粘蜂蜜减速毯",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.35 / 移速40%",
    "recipe": "皇家蜂蜜×1+云朵布×1",
    "tags": [
      "机关砖",
      "定身"
    ],
    "value": 46,
    "desc": "粘住经过的怪物或玩家脚底，使其在2秒内无法跳跃或冲锋",
    "color1": "#F77F00",
    "color2": "#FCBF49",
    "shape": "tile"
  },
  "323": {
    "id": 323,
    "name": "流沙向心漩涡砖",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.65 / 聚怪吸力",
    "recipe": "石英砂×2+魔晶簇×1",
    "tags": [
      "机关砖",
      "聚怪"
    ],
    "value": 58,
    "desc": "持续将周围2格内的怪物、玩家和掉落物缓慢吸向漩涡中心",
    "color1": "#E09F3E",
    "color2": "#9E2A2B",
    "shape": "sand"
  },
  "324": {
    "id": 324,
    "name": "倒刺荆棘地垫",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.60 / 流血伤害",
    "recipe": "青竹×2+风草×2",
    "tags": [
      "机关砖",
      "尖刺"
    ],
    "value": 40,
    "desc": "对踩过的野怪造成每秒20点流血，趁果冻王吸气扔进嘴里直接扎晕",
    "color1": "#2D6A4F",
    "color2": "#D90429",
    "shape": "pad"
  },
  "325": {
    "id": 325,
    "name": "迪斯科变色灯砖",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.75 / 移速115%",
    "recipe": "琉璃板×1+魔能线芯×1",
    "tags": [
      "地砖",
      "灯光"
    ],
    "value": 50,
    "desc": "每踩一下在8种霓虹色间切换，多人同时蹦迪触发彩球光效",
    "color1": "#F72585",
    "color2": "#4CC9F0",
    "shape": "grid_block"
  },
  "326": {
    "id": 326,
    "name": "双子星传送地砖A",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.75 / 空间传送",
    "recipe": "秘银锭×1+星辰碎片×1",
    "tags": [
      "机关砖",
      "传送"
    ],
    "value": 130,
    "desc": "站在上面1秒后瞬间传送至同房间配对的【传送地砖B】",
    "color1": "#7209B7",
    "color2": "#4EA8DE",
    "shape": "star"
  },
  "327": {
    "id": 327,
    "name": "双子星传送地砖B",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.75 / 空间传送",
    "recipe": "秘银锭×1+星辰碎片×1",
    "tags": [
      "机关砖",
      "传送"
    ],
    "value": 130,
    "desc": "与传送地砖A双向互通，Boss战紧急逃生通道",
    "color1": "#4EA8DE",
    "color2": "#7209B7",
    "shape": "star"
  },
  "328": {
    "id": 328,
    "name": "矿车笔直铁轨",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.90 / 铁轨",
    "recipe": "寒铁锭×1+松木板×1",
    "tags": [
      "铁轨",
      "载具"
    ],
    "value": 35,
    "desc": "供蒸汽小火车高速滑行，火车撞击铁轨上野怪造成150点碾压伤害",
    "color1": "#5C677D",
    "color2": "#8D5B4C",
    "shape": "rail"
  },
  "329": {
    "id": 329,
    "name": "矿车转弯与爬坡轨",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.90 / 跨层铁轨",
    "recipe": "寒铁锭×1+松木板×2",
    "tags": [
      "铁轨",
      "爬坡"
    ],
    "value": 40,
    "desc": "连接不同方向或不同海拔高度（Z与Z+1）的铁轨",
    "color1": "#5C677D",
    "color2": "#D4A373",
    "shape": "rail"
  },
  "330": {
    "id": 330,
    "name": "矿车制动加速轨",
    "category": "3.5 物理与景观地砖",
    "subCategory": "μ=0.95 / 动力铁轨",
    "recipe": "寒铁锭×1+魔能线芯×2",
    "tags": [
      "铁轨",
      "加速"
    ],
    "value": 55,
    "desc": "通电时为经过的矿车提供全速推力，断电时作为刹车轨停靠",
    "color1": "#D90429",
    "color2": "#FFBE0B",
    "shape": "rail"
  },
  "351": {
    "id": 351,
    "name": "暖松原木圆墙",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "第4层 Wall",
    "recipe": "暖松原木×1",
    "tags": [
      "墙体",
      "木质"
    ],
    "value": 12,
    "desc": "森林小木屋质感，四向转角自动拼接",
    "color1": "#8D5B4C",
    "color2": "#B07D62",
    "shape": "wall"
  },
  "352": {
    "id": 352,
    "name": "复古红砖承重墙",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "第4层 Wall",
    "recipe": "窑烧红砖块×1",
    "tags": [
      "墙体",
      "砖石"
    ],
    "value": 22,
    "desc": "欧式庄园与工坊风格，坚固厚重",
    "color1": "#B23A48",
    "color2": "#E28743",
    "shape": "wall"
  },
  "353": {
    "id": 353,
    "name": "奶油白灰泥墙",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "第4层 Wall",
    "recipe": "圆石×1+红黏土×1",
    "tags": [
      "墙体",
      "涂装"
    ],
    "value": 20,
    "desc": "地中海绘本小镇风，最适合用染色喷枪涂刷成马卡龙色",
    "color1": "#F8F9FA",
    "color2": "#E9ECEF",
    "shape": "wall"
  },
  "354": {
    "id": 354,
    "name": "日式障子纸格墙",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "第4层 Wall",
    "recipe": "樱木板×1+风草×1",
    "tags": [
      "墙体",
      "和风"
    ],
    "value": 28,
    "desc": "透出屋内温暖橘光，搭配温泉旅馆绝佳",
    "color1": "#F4F1DE",
    "color2": "#8D5B4C",
    "shape": "wall"
  },
  "355": {
    "id": 355,
    "name": "全透明落地玻璃墙",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "第4层 Wall",
    "recipe": "全透琉璃板×1",
    "tags": [
      "墙体",
      "透明"
    ],
    "value": 35,
    "desc": "建造阳光花房、怪物生态观察室与百货橱窗必备",
    "color1": "#90E0EF",
    "color2": "#FFFFFF",
    "shape": "glass"
  },
  "356": {
    "id": 356,
    "name": "哥特彩绘花窗墙",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "第4层 Wall",
    "recipe": "琉璃板×1+染料×2",
    "tags": [
      "墙体",
      "彩绘"
    ],
    "value": 50,
    "desc": "阳光照射下在室内地面投射出绚丽的彩色光斑",
    "color1": "#7209B7",
    "color2": "#FFB703",
    "shape": "glass"
  },
  "357": {
    "id": 357,
    "name": "翠竹编织篱笆墙",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "第4层 Wall",
    "recipe": "翠玉青竹×2",
    "tags": [
      "墙体",
      "半高"
    ],
    "value": 20,
    "desc": "半高透气围栏，可圈养动物，弓箭与水枪可隔着篱笆射击",
    "color1": "#58A65C",
    "color2": "#A8E6CF",
    "shape": "wall"
  },
  "358": {
    "id": 358,
    "name": "盛开花藤绿植墙",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "第4层 Wall",
    "recipe": "风草×2+甜莓×1",
    "tags": [
      "墙体",
      "生态"
    ],
    "value": 28,
    "desc": "随微风摇摆的鲜花拱墙，自然吸引蝴蝶与蜜蜂生成",
    "color1": "#2A9D8F",
    "color2": "#FF758F",
    "shape": "wall"
  },
  "359": {
    "id": 359,
    "name": "黑曜石防爆城墙",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "第4层 Wall",
    "recipe": "黑曜石块×1",
    "tags": [
      "墙体",
      "防爆"
    ],
    "value": 65,
    "desc": "免疫Boss冲撞破坏，能将滑冰撞上来的【深渊晶甲巨蟹】反震破甲",
    "color1": "#2C223E",
    "color2": "#9B5DE5",
    "shape": "wall"
  },
  "360": {
    "id": 360,
    "name": "焦糖威化巧克力墙",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "第4层 Wall",
    "recipe": "焦糖威化木×1",
    "tags": [
      "墙体",
      "甜食"
    ],
    "value": 38,
    "desc": "甜点屋专属墙体，吸引附近果冻怪主动跑来啃墙从而聚怪",
    "color1": "#6F4E37",
    "color2": "#F7D08A",
    "shape": "wall"
  },
  "361": {
    "id": 361,
    "name": "高弹软包防撞墙",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "第4层 Wall",
    "recipe": "云朵布×1+果冻胶×1",
    "tags": [
      "墙体",
      "反弹"
    ],
    "value": 55,
    "desc": "撞上去的果冻球、滑行玩家或穿山甲怪以100%速度弹性反弹",
    "color1": "#FF99C8",
    "color2": "#FFFFFF",
    "shape": "wall"
  },
  "362": {
    "id": 362,
    "name": "单向透视暗道墙",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "第4层 Wall",
    "recipe": "松木板×1+变身菇×1",
    "tags": [
      "墙体",
      "密室"
    ],
    "value": 60,
    "desc": "外观是实心砖墙，但玩家可直接穿墙躲避怪物追击",
    "color1": "#6C757D",
    "color2": "#00F5D4",
    "shape": "wall"
  },
  "363": {
    "id": 363,
    "name": "温馨圆拱小木门",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "第4层 Door",
    "recipe": "精刨松木板×2",
    "tags": [
      "门窗",
      "木门"
    ],
    "value": 25,
    "desc": "玩家靠近手动推开关上，野生怪物无法开门，BFS房间识别件",
    "color1": "#B07D62",
    "color2": "#FFD166",
    "shape": "door"
  },
  "364": {
    "id": 364,
    "name": "迎宾双开雕花门",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "第4层 Door",
    "recipe": "樱木板×3+黄铜锭×1",
    "tags": [
      "门窗",
      "大门"
    ],
    "value": 55,
    "desc": "占地2×1的气派大门，适合餐馆与冒险者公会大厅",
    "color1": "#A65E6E",
    "color2": "#F39C12",
    "shape": "door"
  },
  "365": {
    "id": 365,
    "name": "自动感应平移玻璃门",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "第4层 Door",
    "recipe": "琉璃板×2+魔晶簇×1",
    "tags": [
      "门窗",
      "自动"
    ],
    "value": 70,
    "desc": "仅对玩家、森灵与宠物自动感应开启，将野生怪物挡在门外",
    "color1": "#4CC9F0",
    "color2": "#FFFFFF",
    "shape": "door"
  },
  "366": {
    "id": 366,
    "name": "单向通行旋转栅门",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "第4层 Door",
    "recipe": "寒铁金属锭×2",
    "tags": [
      "门窗",
      "单向"
    ],
    "value": 58,
    "desc": "只允许从A侧走向B侧，可把野生怪物引诱进包围圈锁住",
    "color1": "#5C677D",
    "color2": "#ADB5BD",
    "shape": "door"
  },
  "367": {
    "id": 367,
    "name": "四位数字密码铁门",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "第4层 Door",
    "recipe": "寒铁锭×3+发条齿轮×2",
    "tags": [
      "门窗",
      "密码"
    ],
    "value": 85,
    "desc": "房主可设定4位密码或连接电路与门，解谜成功才开启",
    "color1": "#343A40",
    "color2": "#FF006E",
    "shape": "door"
  },
  "368": {
    "id": 368,
    "name": "多人合力千斤石门",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "第4层 Door",
    "recipe": "圆石×6+寒铁锭×2",
    "tags": [
      "门窗",
      "合力"
    ],
    "value": 90,
    "desc": "必须3名以上玩家同时站在门前按住互动键才能推开",
    "color1": "#7F8C8D",
    "color2": "#F39C12",
    "shape": "door"
  },
  "369": {
    "id": 369,
    "name": "投币收费检票闸门",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "第4层 Door",
    "recipe": "黄铜锭×2+发条齿轮×1",
    "tags": [
      "门窗",
      "收费"
    ],
    "value": 75,
    "desc": "访客需投入房主指定的物品门票才放行1次",
    "color1": "#E09F3E",
    "color2": "#2A9D8F",
    "shape": "door"
  },
  "370": {
    "id": 370,
    "name": "暖阳木框观景窗",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "第4层 Wall",
    "recipe": "松木板×1+琉璃板×1",
    "tags": [
      "门窗",
      "采光"
    ],
    "value": 30,
    "desc": "嵌入墙体中，夜晚向外透出室内温暖橘光",
    "color1": "#B07D62",
    "color2": "#90E0EF",
    "shape": "glass"
  },
  "371": {
    "id": 371,
    "name": "传菜与射击窗口墙",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "第4层 Wall",
    "recipe": "精刨松木板×2",
    "tags": [
      "门窗",
      "窗口"
    ],
    "value": 28,
    "desc": "怪物过不来，玩家可隔窗递菜或用猎弓法杖安全射击窗外野怪",
    "color1": "#D4A373",
    "color2": "#FFF8E7",
    "shape": "wall"
  },
  "372": {
    "id": 372,
    "name": "暖红陶瓦斜屋顶",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "第5层 Roof",
    "recipe": "窑烧红砖块×1",
    "tags": [
      "屋顶",
      "陶瓦"
    ],
    "value": 22,
    "desc": "经典绘本红屋顶，角色走入室内时整片连通屋顶自动变透明",
    "color1": "#E63946",
    "color2": "#B23A48",
    "shape": "roof"
  },
  "373": {
    "id": 373,
    "name": "森林茅草厚屋顶",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "第5层 Roof",
    "recipe": "柔韧风草×2",
    "tags": [
      "屋顶",
      "茅草"
    ],
    "value": 16,
    "desc": "质朴童话风，雨天边缘有晶莹雨滴滑落特效",
    "color1": "#E9C46A",
    "color2": "#F4A261",
    "shape": "roof"
  },
  "374": {
    "id": 374,
    "name": "蔚蓝童话尖塔顶",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "第5层 Roof",
    "recipe": "圆石×1+星夜染料×1",
    "tags": [
      "屋顶",
      "尖塔"
    ],
    "value": 45,
    "desc": "城堡高塔专属尖顶，顶部自带随风转动的风向标",
    "color1": "#3A86FF",
    "color2": "#FFD166",
    "shape": "roof"
  },
  "375": {
    "id": 375,
    "name": "阳光温室玻璃顶",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "第5层 Roof",
    "recipe": "全透琉璃板×1",
    "tags": [
      "屋顶",
      "透光"
    ],
    "value": 38,
    "desc": "全天候透光，触发【自动物流温室】房间识别的必要条件",
    "color1": "#90E0EF",
    "color2": "#FFFFFF",
    "shape": "roof"
  },
  "376": {
    "id": 376,
    "name": "紫藤花架凉亭顶",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "第5层 Roof",
    "recipe": "青竹×1+绯樱原木×1",
    "tags": [
      "屋顶",
      "花架"
    ],
    "value": 35,
    "desc": "半透光花藤顶，地面投下斑驳晃动的树影",
    "color1": "#9B5DE5",
    "color2": "#58A65C",
    "shape": "roof"
  },
  "377": {
    "id": 377,
    "name": "宽敞原木斜坡阶梯",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "高低差构件",
    "recipe": "精刨松木板×2",
    "tags": [
      "阶梯",
      "跨层"
    ],
    "value": 25,
    "desc": "连接海拔Z与Z+1，支持玩家与小推车平顺上下",
    "color1": "#B07D62",
    "color2": "#8D5B4C",
    "shape": "stairs"
  },
  "378": {
    "id": 378,
    "name": "雕刻青石台阶",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "高低差构件",
    "recipe": "云母圆石×2",
    "tags": [
      "阶梯",
      "石阶"
    ],
    "value": 25,
    "desc": "稳重的石质阶梯，适合山城与神殿入口",
    "color1": "#7F8C8D",
    "color2": "#BDC3C7",
    "shape": "stairs"
  },
  "379": {
    "id": 379,
    "name": "垂直攀爬藤蔓梯",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "高低差构件",
    "recipe": "结实风草绳×2",
    "tags": [
      "阶梯",
      "攀爬"
    ],
    "value": 22,
    "desc": "贴在Z1/Z2悬崖侧壁上，玩家可爬上高台居高临下射击野怪",
    "color1": "#58A65C",
    "color2": "#8A9A86",
    "shape": "stairs"
  },
  "380": {
    "id": 380,
    "name": "跨高台摇晃吊桥",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "高低差构件",
    "recipe": "松木板×2+风草绳×2",
    "tags": [
      "桥梁",
      "悬空"
    ],
    "value": 45,
    "desc": "架设在两座高台之间，下方地面怪物无法够到桥上的玩家",
    "color1": "#B07D62",
    "color2": "#D4E09B",
    "shape": "plank"
  },
  "381": {
    "id": 381,
    "name": "青石圆拱跨河桥",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "高低差构件",
    "recipe": "云母圆石×4",
    "tags": [
      "桥梁",
      "拱桥"
    ],
    "value": 48,
    "desc": "横跨Z=-1河道，船只或漂流的木头可从拱洞流过",
    "color1": "#7F8C8D",
    "color2": "#E8EEF1",
    "shape": "stairs"
  },
  "382": {
    "id": 382,
    "name": "高空飞跃滑索柱",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "高低差构件",
    "recipe": "寒铁锭×2+风草绳×2",
    "tags": [
      "滑索",
      "位移"
    ],
    "value": 80,
    "desc": "在Boss战场两端架设滑索，可在Boss放全屏大招时极速横穿战场",
    "color1": "#5C677D",
    "color2": "#FFBE0B",
    "shape": "staff"
  },
  "383": {
    "id": 383,
    "name": "悬崖防摔木护栏",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "边缘构件",
    "recipe": "精刨松木板×1",
    "tags": [
      "护栏",
      "防摔"
    ],
    "value": 15,
    "desc": "安装在高台边缘防止走路掉下悬崖（仍可被充气大锤锤飞越过）",
    "color1": "#B07D62",
    "color2": "#E6CCB2",
    "shape": "wall"
  },
  "384": {
    "id": 384,
    "name": "屋顶炊烟小烟囱",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "屋顶装饰",
    "recipe": "窑烧红砖块×2",
    "tags": [
      "装饰",
      "炊烟"
    ],
    "value": 30,
    "desc": "安装在屋顶上，只要屋内壁炉或汤锅运转就会冒出云朵状白烟",
    "color1": "#B23A48",
    "color2": "#FFFFFF",
    "shape": "wall"
  },
  "385": {
    "id": 385,
    "name": "二层雕花露台栏杆",
    "category": "3.6 墙体门窗与屋顶",
    "subCategory": "边缘构件",
    "recipe": "绯樱香木板×1",
    "tags": [
      "护栏",
      "露台"
    ],
    "value": 22,
    "desc": "在高台打造露天咖啡座与观景阳台的精致围栏",
    "color1": "#D88C9A",
    "color2": "#FFF8E7",
    "shape": "wall"
  },
  "401": {
    "id": 401,
    "name": "轻触木质压力板",
    "category": "3.7 电路机关与载具",
    "subCategory": "传感器",
    "recipe": "松木板×1+跳跳菇×1",
    "tags": [
      "电路",
      "传感"
    ],
    "value": 35,
    "desc": "任何玩家、动物或掉落物压在上面时输出高电平1，离开归0",
    "color1": "#D4A373",
    "color2": "#FF595E",
    "shape": "pad"
  },
  "402": {
    "id": 402,
    "name": "双人重物压力板",
    "category": "3.7 电路机关与载具",
    "subCategory": "传感器",
    "recipe": "寒铁锭×2+跳跳菇×1",
    "tags": [
      "电路",
      "多人"
    ],
    "value": 65,
    "desc": "必须2名以上玩家同时站立或巨型Boss踩上去才输出1",
    "color1": "#5C677D",
    "color2": "#FFBE0B",
    "shape": "pad"
  },
  "403": {
    "id": 403,
    "name": "双态机械拉杆",
    "category": "3.7 电路机关与载具",
    "subCategory": "传感器",
    "recipe": "暖松原木×1+黄铜锭×1",
    "tags": [
      "电路",
      "开关"
    ],
    "value": 40,
    "desc": "玩家点击切换常开1/常闭0，控制工厂总电源或困怪笼开关",
    "color1": "#8D5B4C",
    "color2": "#9B5DE5",
    "shape": "lever"
  },
  "404": {
    "id": 404,
    "name": "瞬时脉冲按钮",
    "category": "3.7 电路机关与载具",
    "subCategory": "传感器",
    "recipe": "圆石×1+魔能线芯×1",
    "tags": [
      "电路",
      "按钮"
    ],
    "value": 32,
    "desc": "按下后输出0.5秒高电平随后自动弹回",
    "color1": "#7F8C8D",
    "color2": "#EF233C",
    "shape": "pad"
  },
  "405": {
    "id": 405,
    "name": "昼夜星光感光器",
    "category": "3.7 电路机关与载具",
    "subCategory": "传感器",
    "recipe": "琉璃板×1+魔晶簇×1",
    "tags": [
      "电路",
      "感光"
    ],
    "value": 68,
    "desc": "夜晚自动输出1，可自动升起城镇外围隐藏墙阻挡夜间野怪进村",
    "color1": "#3A0CA3",
    "color2": "#FFD166",
    "shape": "crystal"
  },
  "406": {
    "id": 406,
    "name": "河道水位传感器",
    "category": "3.7 电路机关与载具",
    "subCategory": "传感器",
    "recipe": "黄铜锭×1+多孔浮石×1",
    "tags": [
      "电路",
      "水位"
    ],
    "value": 62,
    "desc": "当所在格有水体漫入时输出1，用于自动防洪闸门",
    "color1": "#4EA8DE",
    "color2": "#E09F3E",
    "shape": "compass"
  },
  "407": {
    "id": 407,
    "name": "红外激光绊线柱",
    "category": "3.7 电路机关与载具",
    "subCategory": "传感器",
    "recipe": "秘银锭×1+魔晶簇×2",
    "tags": [
      "电路",
      "激光"
    ],
    "value": 95,
    "desc": "野生动物或Boss穿过红光瞬间输出脉冲，自动触发一排连弩陷阱",
    "color1": "#EF233C",
    "color2": "#5C677D",
    "shape": "staff"
  },
  "408": {
    "id": 408,
    "name": "共鸣音高传感器",
    "category": "3.7 电路机关与载具",
    "subCategory": "传感器",
    "recipe": "青竹×2+魔晶簇×1",
    "tags": [
      "电路",
      "声控"
    ],
    "value": 85,
    "desc": "设定指定音高，只有玩家在旁边用乐器弹出该音符时才开门",
    "color1": "#06D6A0",
    "color2": "#FFD166",
    "shape": "note_block"
  },
  "409": {
    "id": 409,
    "name": "仓库满载传感器",
    "category": "3.7 电路机关与载具",
    "subCategory": "传感器",
    "recipe": "松木板×1+魔能线芯×1",
    "tags": [
      "电路",
      "物流"
    ],
    "value": 45,
    "desc": "贴在储物箱旁，当箱子装满时输出1通知收货",
    "color1": "#D4A373",
    "color2": "#06D6A0",
    "shape": "chest"
  },
  "410": {
    "id": 410,
    "name": "红蓝计分球门框",
    "category": "3.7 电路机关与载具",
    "subCategory": "竞技传感",
    "recipe": "寒铁锭×4+云朵布×2",
    "tags": [
      "竞技",
      "球门"
    ],
    "value": 110,
    "desc": "占地3×1；当果冻足球滚入时输出信号、全房播报比分并放烟花",
    "color1": "#EF233C",
    "color2": "#3A86FF",
    "shape": "door"
  },
  "411": {
    "id": 411,
    "name": "跑酷起点发令门",
    "category": "3.7 电路机关与载具",
    "subCategory": "竞技传感",
    "recipe": "樱木板×2+魔能线芯×2",
    "tags": [
      "竞技",
      "起点"
    ],
    "value": 80,
    "desc": "裁判吹哨时门栏降下，为穿过的每名玩家开启毫秒级个人计时器",
    "color1": "#06D6A0",
    "color2": "#FFFFFF",
    "shape": "door"
  },
  "412": {
    "id": 412,
    "name": "跑酷终点领奖台",
    "category": "3.7 电路机关与载具",
    "subCategory": "竞技传感",
    "recipe": "曜金矿×2+圆石×2",
    "tags": [
      "竞技",
      "终点"
    ],
    "value": 120,
    "desc": "冲上领奖台瞬间停止计时，在全房头顶滚动播报前三名耗时",
    "color1": "#FFD166",
    "color2": "#EF233C",
    "shape": "pad"
  },
  "413": {
    "id": 413,
    "name": "可调延时继电器",
    "category": "3.7 电路机关与载具",
    "subCategory": "逻辑控制",
    "recipe": "黄铜锭×1+发条齿轮×1",
    "tags": [
      "电路",
      "延时"
    ],
    "value": 55,
    "desc": "点击切换延迟0.2s/0.5s/1.0s/2.0s后向下一节点传递信号",
    "color1": "#E09F3E",
    "color2": "#4CC9F0",
    "shape": "gear"
  },
  "414": {
    "id": 414,
    "name": "魔能逻辑与门(AND)",
    "category": "3.7 电路机关与载具",
    "subCategory": "逻辑控制",
    "recipe": "黄铜锭×1+魔能线芯×2",
    "tags": [
      "电路",
      "逻辑"
    ],
    "value": 58,
    "desc": "仅当连接的红线与蓝线同时为1时，向黄线输出1",
    "color1": "#3A86FF",
    "color2": "#FF006E",
    "shape": "grid_block"
  },
  "415": {
    "id": 415,
    "name": "魔能逻辑非门(NOT)",
    "category": "3.7 电路机关与载具",
    "subCategory": "逻辑控制",
    "recipe": "黄铜锭×1+魔能线芯×1",
    "tags": [
      "电路",
      "反转"
    ],
    "value": 50,
    "desc": "输入0时输出1，配合延时器可组成周期脉冲时钟",
    "color1": "#EF233C",
    "color2": "#FFBE0B",
    "shape": "grid_block"
  },
  "416": {
    "id": 416,
    "name": "随机轮盘分流器",
    "category": "3.7 电路机关与载具",
    "subCategory": "逻辑控制",
    "recipe": "发条齿轮×2+线芯×2",
    "tags": [
      "电路",
      "随机"
    ],
    "value": 65,
    "desc": "收到信号时随机向东南西三路中的一路输出信号，做盲盒抽奖机",
    "color1": "#9B5DE5",
    "color2": "#FFD166",
    "shape": "gear"
  },
  "417": {
    "id": 417,
    "name": "0-99翻页计数器",
    "category": "3.7 电路机关与载具",
    "subCategory": "逻辑显示",
    "recipe": "寒铁锭×2+松木板×2",
    "tags": [
      "电路",
      "显示"
    ],
    "value": 75,
    "desc": "每次收到脉冲数字+1，可在球场或刷怪塔旁拼出实时大比分牌",
    "color1": "#212529",
    "color2": "#00F5D4",
    "shape": "grid_block"
  },
  "418": {
    "id": 418,
    "name": "无线信号发射塔",
    "category": "3.7 电路机关与载具",
    "subCategory": "跨区控制",
    "recipe": "秘银锭×1+星辰碎片×1",
    "tags": [
      "电路",
      "无线"
    ],
    "value": 140,
    "desc": "将信号无线广播至同房间相同频道（1~8频道）的接收器",
    "color1": "#4CC9F0",
    "color2": "#7209B7",
    "shape": "star"
  },
  "419": {
    "id": 419,
    "name": "32音高八音盒音符砖",
    "category": "3.7 电路机关与载具",
    "subCategory": "执行器",
    "recipe": "樱木板×1+魔晶簇×1",
    "tags": [
      "音符",
      "演奏"
    ],
    "value": 65,
    "desc": "通电或踩踏播放设定音高（木琴/钢琴/八音盒/合成器），可串联编曲",
    "color1": "#C68B59",
    "color2": "#64FFDA",
    "shape": "note_block"
  },
  "420": {
    "id": 420,
    "name": "16色RGB像素灯箱",
    "category": "3.7 电路机关与载具",
    "subCategory": "执行器",
    "recipe": "琉璃板×1+魔晶簇×1",
    "tags": [
      "灯箱",
      "像素"
    ],
    "value": 60,
    "desc": "通电点亮，用扳手切换16种颜色，拼成矩阵播放动态像素动画",
    "color1": "#FF006E",
    "color2": "#00F5D4",
    "shape": "grid_block"
  },
  "421": {
    "id": 421,
    "name": "升降隐藏机关墙",
    "category": "3.7 电路机关与载具",
    "subCategory": "执行器",
    "recipe": "圆石×2+发条齿轮×1",
    "tags": [
      "机关",
      "隐藏墙"
    ],
    "value": 70,
    "desc": "通电沉入地下，断电升起，可把野怪引诱进房间后拉拉杆困住",
    "color1": "#7F8C8D",
    "color2": "#E09F3E",
    "shape": "wall"
  },
  "422": {
    "id": 422,
    "name": "万向弹射弹簧垫",
    "category": "3.7 电路机关与载具",
    "subCategory": "执行器",
    "recipe": "寒铁锭×1+跳跳菇×2",
    "tags": [
      "机关",
      "弹射"
    ],
    "value": 85,
    "desc": "将上方的玩家、炸弹果或中小型野怪向设定方向抛射5格远",
    "color1": "#5C677D",
    "color2": "#FFBE0B",
    "shape": "pad"
  },
  "423": {
    "id": 423,
    "name": "360°大风车旋转推杆",
    "category": "3.7 电路机关与载具",
    "subCategory": "执行器",
    "recipe": "暖松原木×4+齿轮×2",
    "tags": [
      "机关",
      "旋转杆"
    ],
    "value": 95,
    "desc": "通电后3格软包横杆持续旋转，扫飞跑酷玩家或做成自动打怪机",
    "color1": "#E09F3E",
    "color2": "#FF006E",
    "shape": "sweeper"
  },
  "424": {
    "id": 424,
    "name": "伸缩推拉活塞臂",
    "category": "3.7 电路机关与载具",
    "subCategory": "执行器",
    "recipe": "黄铜锭×2+松木板×1",
    "tags": [
      "机关",
      "活塞"
    ],
    "value": 80,
    "desc": "通电向前伸出1格推动方块、箱子或把怪物推下高台",
    "color1": "#D4AC0D",
    "color2": "#5C677D",
    "shape": "arm"
  },
  "425": {
    "id": 425,
    "name": "自动泡泡连弩炮台",
    "category": "3.7 电路机关与载具",
    "subCategory": "防御执行",
    "recipe": "青竹×2+发条齿轮×2",
    "tags": [
      "防御塔",
      "射击"
    ],
    "value": 105,
    "desc": "自动瞄准半径7格内的敌对野生动物发射泡泡或木箭",
    "color1": "#58A65C",
    "color2": "#4CC9F0",
    "shape": "gun"
  },
  "426": {
    "id": 426,
    "name": "旋转自动洒水器",
    "category": "3.7 电路机关与载具",
    "subCategory": "农业物流",
    "recipe": "黄铜锭×2+青竹×1",
    "tags": [
      "农业",
      "灌溉"
    ],
    "value": 75,
    "desc": "每早自动旋转将周围5×5耕地全部浇湿",
    "color1": "#4EA8DE",
    "color2": "#E09F3E",
    "shape": "gear"
  },
  "427": {
    "id": 427,
    "name": "电动升降拦水闸门",
    "category": "3.7 电路机关与载具",
    "subCategory": "水利控制",
    "recipe": "寒铁锭×2+发条齿轮×1",
    "tags": [
      "水利",
      "闸门"
    ],
    "value": 90,
    "desc": "安装在Z=-1河道中，通电开闸放洪水冲毁【机甲河狸Boss】的木坝",
    "color1": "#5C677D",
    "color2": "#4EA8DE",
    "shape": "door"
  },
  "428": {
    "id": 428,
    "name": "定向物流传送带",
    "category": "3.7 电路机关与载具",
    "subCategory": "自动化",
    "recipe": "寒铁锭×1+果冻胶×1",
    "tags": [
      "物流",
      "传送带"
    ],
    "value": 65,
    "desc": "每秒将掉落在上面的战利品、矿石或站在上面的怪物运往下一格",
    "color1": "#495057",
    "color2": "#FFBE0B",
    "shape": "belt"
  },
  "429": {
    "id": 429,
    "name": "智能分拣交叉带",
    "category": "3.7 电路机关与载具",
    "subCategory": "自动化",
    "recipe": "黄铜锭×1+发条齿轮×1",
    "tags": [
      "物流",
      "分拣"
    ],
    "value": 85,
    "desc": "设定过滤物品ID，将怪物掉落的材料自动分流进不同储物箱",
    "color1": "#E09F3E",
    "color2": "#06D6A0",
    "shape": "belt"
  },
  "430": {
    "id": 430,
    "name": "魔能抓取机械臂",
    "category": "3.7 电路机关与载具",
    "subCategory": "自动化",
    "recipe": "秘银锭×1+发条齿轮×2",
    "tags": [
      "物流",
      "机械臂"
    ],
    "value": 125,
    "desc": "自动抓取地面掉落物或箱内物品，放入熔炉、汤锅或防御炮台",
    "color1": "#D4AC0D",
    "color2": "#2EC4B6",
    "shape": "arm"
  },
  "431": {
    "id": 431,
    "name": "自动采矿钻头机",
    "category": "3.7 电路机关与载具",
    "subCategory": "自动化",
    "recipe": "寒铁锭×4+魔晶簇×2",
    "tags": [
      "采矿",
      "自动化"
    ],
    "value": 135,
    "desc": "架设在矿脉格旁，在风车动力网覆盖下每10秒自动产出一块矿石",
    "color1": "#5C677D",
    "color2": "#FF9F1C",
    "shape": "pickaxe"
  },
  "432": {
    "id": 432,
    "name": "庆典烟花发射座",
    "category": "3.7 电路机关与载具",
    "subCategory": "氛围执行",
    "recipe": "红砖×2+爆裂火椒×2",
    "tags": [
      "烟花",
      "庆典"
    ],
    "value": 70,
    "desc": "通电时向高空连发5枚绚丽礼花，常与球门或蓝图落成相连",
    "color1": "#E63946",
    "color2": "#FFD166",
    "shape": "bomb"
  },
  "433": {
    "id": 433,
    "name": "巨型果冻足球生成座",
    "category": "3.7 电路机关与载具",
    "subCategory": "竞技设施",
    "recipe": "果冻胶×4+圆石×2",
    "tags": [
      "竞技",
      "足球"
    ],
    "value": 90,
    "desc": "点击或通电刷出一颗高弹大果冻球，掉水里自动重置回底座",
    "color1": "#06D6A0",
    "color2": "#FFFFFF",
    "shape": "slime_ball"
  },
  "434": {
    "id": 434,
    "name": "争夺战金皇冠底座",
    "category": "3.7 电路机关与载具",
    "subCategory": "竞技设施",
    "recipe": "曜金矿×3+云朵布×1",
    "tags": [
      "竞技",
      "皇冠"
    ],
    "value": 140,
    "desc": "开启3分钟抢皇冠大逃杀，实时统计每名玩家持冠秒数",
    "color1": "#FFD166",
    "color2": "#EF233C",
    "shape": "crown"
  },
  "435": {
    "id": 435,
    "name": "四色队伍出生复活旗",
    "category": "3.7 电路机关与载具",
    "subCategory": "竞技设施",
    "recipe": "松木板×2+云朵布×2",
    "tags": [
      "竞技",
      "复活"
    ],
    "value": 60,
    "desc": "切换红/蓝/黄/绿四队归属，比赛或Boss战倒地玩家在旗帜旁复活",
    "color1": "#3A86FF",
    "color2": "#FF006E",
    "shape": "flag"
  },
  "436": {
    "id": 436,
    "name": "派对裁判控制哨台",
    "category": "3.7 电路机关与载具",
    "subCategory": "竞技核心",
    "recipe": "樱木板×4+黄铜锭×2",
    "tags": [
      "竞技",
      "控制台"
    ],
    "value": 110,
    "desc": "一键开启造桥跑酷赛 / 4v4果冻球 / 抢皇冠 / 涂色大作战",
    "color1": "#A65E6E",
    "color2": "#FFD166",
    "shape": "podium"
  },
  "437": {
    "id": 437,
    "name": "叮当蒸汽小火车头",
    "category": "3.7 电路机关与载具",
    "subCategory": "多人载具",
    "recipe": "寒铁锭×6+黄铜锭×4",
    "tags": [
      "载具",
      "火车"
    ],
    "value": 220,
    "desc": "沿铁轨高速行驶，撞击铁轨上的野怪直接造成150点碾压击飞伤害",
    "color1": "#C0564B",
    "color2": "#F39C12",
    "shape": "train"
  },
  "438": {
    "id": 438,
    "name": "观光与货运矿车厢",
    "category": "3.7 电路机关与载具",
    "subCategory": "多人载具",
    "recipe": "寒铁锭×3+松木板×2",
    "tags": [
      "载具",
      "车厢"
    ],
    "value": 110,
    "desc": "挂在火车头后，队友可坐在移动车厢上用弓箭对沿途Boss移动射击",
    "color1": "#8D5B4C",
    "color2": "#5C677D",
    "shape": "cart"
  },
  "439": {
    "id": 439,
    "name": "双人天鹅脚踏船",
    "category": "3.7 电路机关与载具",
    "subCategory": "多人载具",
    "recipe": "松木板×4+云朵布×2",
    "tags": [
      "载具",
      "船只"
    ],
    "value": 120,
    "desc": "放入湖泊与运河中，2人同乘且节奏一致时划船速度翻倍",
    "color1": "#FFFFFF",
    "color2": "#FFB7C5",
    "shape": "ship"
  },
  "440": {
    "id": 440,
    "name": "八人云海探险飞艇",
    "category": "3.7 电路机关与载具",
    "subCategory": "多人载具",
    "recipe": "秘银锭×6+云朵布×10",
    "tags": [
      "载具",
      "飞艇"
    ],
    "value": 350,
    "desc": "支持最多8人同时登船，追击【星穹幻彩云鲸Boss】或跨房间串门",
    "color1": "#D4A373",
    "color2": "#FFFFFF",
    "shape": "ship"
  },
  "501": {
    "id": 501,
    "name": "暖心篝火茶座",
    "category": "3.8 工坊与房间家具",
    "subCategory": "2×2",
    "recipe": "暖松原木×10+圆石×8",
    "tags": [
      "核心",
      "回血"
    ],
    "value": 60,
    "desc": "城镇初始重生与回血核心；周围4格每秒恢复5 HP，打盹攒露水翻倍",
    "color1": "#E07A5F",
    "color2": "#FFBE0B",
    "shape": "campfire"
  },
  "502": {
    "id": 502,
    "name": "森系木工营造台",
    "category": "3.8 工坊与房间家具",
    "subCategory": "2×1",
    "recipe": "暖松原木×6",
    "tags": [
      "工坊",
      "木工"
    ],
    "value": 40,
    "desc": "解锁木板加工、基础墙体门窗、木质家具与初级木制武器合成",
    "color1": "#B07D62",
    "color2": "#E6CCB2",
    "shape": "table"
  },
  "503": {
    "id": 503,
    "name": "矮人鼓风高炉",
    "category": "3.8 工坊与房间家具",
    "subCategory": "2×2",
    "recipe": "圆石×12+红黏土×8",
    "tags": [
      "工坊",
      "冶炼"
    ],
    "value": 85,
    "desc": "冶炼金属锭、烧制红砖与玻璃（【大师锻造房】核心件）",
    "color1": "#5C677D",
    "color2": "#F48C06",
    "shape": "furnace"
  },
  "504": {
    "id": 504,
    "name": "大师秘银铁砧台",
    "category": "3.8 工坊与房间家具",
    "subCategory": "2×1",
    "recipe": "寒铁锭×6+暖松原木×2",
    "tags": [
      "工坊",
      "锻造"
    ],
    "value": 110,
    "desc": "锻造中高级武器护甲、发条齿轮与魔能电路（【大师锻造房】核心件）",
    "color1": "#343A40",
    "color2": "#48C9B0",
    "shape": "anvil"
  },
  "505": {
    "id": 505,
    "name": "炼金调色染缸",
    "category": "3.8 工坊与房间家具",
    "subCategory": "2×2",
    "recipe": "松木板×6+红黏土×4",
    "tags": [
      "工坊",
      "染色"
    ],
    "value": 75,
    "desc": "熬制恢复药水、果冻胶、调配32色染料（【绘本艺术画廊】核心件）",
    "color1": "#9B5DE5",
    "color2": "#FF006E",
    "shape": "cauldron"
  },
  "506": {
    "id": 506,
    "name": "八人欢聚大汤锅",
    "category": "3.8 工坊与房间家具",
    "subCategory": "2×2",
    "recipe": "寒铁锭×6+红砖块×6",
    "tags": [
      "工坊",
      "火锅"
    ],
    "value": 130,
    "desc": "【欢聚大锅食堂】核心件；全房一起投料（或偷放变身菇）煮全团大餐",
    "color1": "#495057",
    "color2": "#E63946",
    "shape": "cauldron"
  },
  "507": {
    "id": 507,
    "name": "胡闹切菜传菜台",
    "category": "3.8 工坊与房间家具",
    "subCategory": "2×1",
    "recipe": "樱木板×4+寒铁锭×1",
    "tags": [
      "工坊",
      "切菜"
    ],
    "value": 65,
    "desc": "玩家把打猎野味与果蔬扔上台面，切好后直接扔进大汤锅",
    "color1": "#F2D0A9",
    "color2": "#ADB5BD",
    "shape": "table"
  },
  "508": {
    "id": 508,
    "name": "红砖果木披萨炉",
    "category": "3.8 工坊与房间家具",
    "subCategory": "2×2",
    "recipe": "红砖块×10+原木×4",
    "tags": [
      "工坊",
      "烘焙"
    ],
    "value": 95,
    "desc": "烘烤战前增益面包、蜜桃果酱派与加速披萨",
    "color1": "#B23A48",
    "color2": "#FFBE0B",
    "shape": "furnace"
  },
  "509": {
    "id": 509,
    "name": "叮当果汁水车磨坊",
    "category": "3.8 工坊与房间家具",
    "subCategory": "3×2",
    "recipe": "松木板×12+齿轮×4",
    "tags": [
      "工坊",
      "水力"
    ],
    "value": 150,
    "desc": "紧贴浅水河道建造；利用水力自动磨面粉、榨果酱并提供动力网",
    "color1": "#8D5B4C",
    "color2": "#4EA8DE",
    "shape": "gear"
  },
  "510": {
    "id": 510,
    "name": "波波森灵小木屋",
    "category": "3.8 工坊与房间家具",
    "subCategory": "2×2",
    "recipe": "松木板×10+风草×10",
    "tags": [
      "自动化",
      "森灵"
    ],
    "value": 120,
    "desc": "绑定1只波波森灵，自动替玩家打理周围9×9范围浇水、收菜或喂动物",
    "color1": "#58A65C",
    "color2": "#E9C46A",
    "shape": "hut"
  },
  "511": {
    "id": 511,
    "name": "16×16绘本像素画架",
    "category": "3.8 工坊与房间家具",
    "subCategory": "1×1",
    "recipe": "樱木板×3+云朵布×2",
    "tags": [
      "UGC",
      "画架"
    ],
    "value": 80,
    "desc": "【绘本艺术画廊】核心件；手绘16×16像素图案生成盾牌纹章与旗帜",
    "color1": "#D4A373",
    "color2": "#FFFFFF",
    "shape": "easel"
  },
  "512": {
    "id": 512,
    "name": "魔法描图制图桌",
    "category": "3.8 工坊与房间家具",
    "subCategory": "2×1",
    "recipe": "樱木板×4+魔晶簇×2",
    "tags": [
      "蓝图",
      "制图"
    ],
    "value": 115,
    "desc": "管理和导出玩家用【魔法描图卷轴】保存的建筑蓝图码",
    "color1": "#3A86FF",
    "color2": "#F4F1DE",
    "shape": "table"
  },
  "513": {
    "id": 513,
    "name": "分类图标储物箱",
    "category": "3.8 工坊与房间家具",
    "subCategory": "1×1",
    "recipe": "精刨松木板×4",
    "tags": [
      "容器",
      "储物"
    ],
    "value": 35,
    "desc": "提供24格存储空间，箱子正面自动显示存放最多物品的卡通图标",
    "color1": "#B07D62",
    "color2": "#F39C12",
    "shape": "chest"
  },
  "514": {
    "id": 514,
    "name": "跨房共享云端保险箱",
    "category": "3.8 工坊与房间家具",
    "subCategory": "1×1",
    "recipe": "黑曜石×4+星辰碎片×1",
    "tags": [
      "容器",
      "跨房"
    ],
    "value": 180,
    "desc": "存放在里面的个人毕业武器与装备，去任何好友房间助战均可取出",
    "color1": "#2C223E",
    "color2": "#70D6FF",
    "shape": "chest"
  },
  "515": {
    "id": 515,
    "name": "无人自助售货摊",
    "category": "3.8 工坊与房间家具",
    "subCategory": "2×1",
    "recipe": "樱木板×6+云朵布×2",
    "tags": [
      "贸易",
      "摆摊"
    ],
    "value": 95,
    "desc": "【云端跨服百货店】核心件；上架稀有Boss材料或AI炼金奇物供游客购买",
    "color1": "#E63946",
    "color2": "#FFFFFF",
    "shape": "table"
  },
  "516": {
    "id": 516,
    "name": "小镇悬赏与任务板",
    "category": "3.8 工坊与房间家具",
    "subCategory": "2×1",
    "recipe": "松木板×4+风草×2",
    "tags": [
      "社交",
      "任务"
    ],
    "value": 55,
    "desc": "每日自动刷新3个全房合作狩猎悬赏与今日建设便利贴",
    "color1": "#8D5B4C",
    "color2": "#FAF0CA",
    "shape": "easel"
  },
  "517": {
    "id": 517,
    "name": "云端软绵绵单人床",
    "category": "3.8 工坊与房间家具",
    "subCategory": "1×2",
    "recipe": "松木板×4+云朵布×3",
    "tags": [
      "家具",
      "床铺"
    ],
    "value": 65,
    "desc": "【森系茶歇卧室】核心件；躺上去每秒快速恢复15 HP并进入打盹状态",
    "color1": "#BDE0FE",
    "color2": "#FFFFFF",
    "shape": "bed"
  },
  "518": {
    "id": 518,
    "name": "双层上下铺木床",
    "category": "3.8 工坊与房间家具",
    "subCategory": "1×2",
    "recipe": "松木板×8+云朵布×6",
    "tags": [
      "家具",
      "双层床"
    ],
    "value": 110,
    "desc": "可同时睡上下两名玩家，睡在上铺还能往下铺扔枕头",
    "color1": "#D4A373",
    "color2": "#FFAFCC",
    "shape": "bed"
  },
  "519": {
    "id": 519,
    "name": "欢聚拼接长餐桌",
    "category": "3.8 工坊与房间家具",
    "subCategory": "2×1",
    "recipe": "绯樱香木板×4",
    "tags": [
      "家具",
      "餐桌"
    ],
    "value": 50,
    "desc": "【欢聚大锅食堂】核心件；多张桌子放在一起自动拼接成超长宴会桌",
    "color1": "#A65E6E",
    "color2": "#F2D0A9",
    "shape": "table"
  },
  "520": {
    "id": 520,
    "name": "软垫小木椅/吧台凳",
    "category": "3.8 工坊与房间家具",
    "subCategory": "1×1",
    "recipe": "松木板×2+云朵布×1",
    "tags": [
      "家具",
      "座椅"
    ],
    "value": 30,
    "desc": "玩家坐下休息回精力（小心队友在上面偷放臭鼬彩虹屁坐垫）",
    "color1": "#B07D62",
    "color2": "#FF595E",
    "shape": "chair"
  },
  "521": {
    "id": 521,
    "name": "树懒摇晃吊床",
    "category": "3.8 工坊与房间家具",
    "subCategory": "2×1",
    "recipe": "风草绳×4+云朵布×2",
    "tags": [
      "家具",
      "吊床"
    ],
    "value": 60,
    "desc": "挂在两棵树之间，躺上去随微风悠闲左右摇摆",
    "color1": "#06D6A0",
    "color2": "#FAF0CA",
    "shape": "bed"
  },
  "522": {
    "id": 522,
    "name": "暖橘光铁艺路灯",
    "category": "3.8 工坊与房间家具",
    "subCategory": "1×1",
    "recipe": "寒铁锭×2+魔晶簇×1",
    "tags": [
      "照明",
      "安全区"
    ],
    "value": 70,
    "desc": "夜晚散发半径5格暖光，且光圈内不会自然刷新敌对夜行怪物",
    "color1": "#343A40",
    "color2": "#FFBE0B",
    "shape": "lamp"
  },
  "523": {
    "id": 523,
    "name": "萤火虫玻璃生态瓶",
    "category": "3.8 工坊与房间家具",
    "subCategory": "1×1",
    "recipe": "琉璃板×1+萤火虫×1",
    "tags": [
      "照明",
      "生态"
    ],
    "value": 55,
    "desc": "摆在桌面上发出灵动微光（卧室与温室房间识别件）",
    "color1": "#90E0EF",
    "color2": "#C5E063",
    "shape": "jar"
  },
  "524": {
    "id": 524,
    "name": "绘本艺术展示画框",
    "category": "3.8 工坊与房间家具",
    "subCategory": "1×1",
    "recipe": "绯樱香木板×2",
    "tags": [
      "装饰",
      "画框"
    ],
    "value": 35,
    "desc": "挂在墙上展示玩家的16×16像素画作（【绘本艺术画廊】核心件）",
    "color1": "#8D5B4C",
    "color2": "#FFD166",
    "shape": "easel"
  },
  "525": {
    "id": 525,
    "name": "武器与盔甲展示架",
    "category": "3.8 工坊与房间家具",
    "subCategory": "1×1",
    "recipe": "松木板×3+寒铁锭×1",
    "tags": [
      "装饰",
      "陈列"
    ],
    "value": 60,
    "desc": "将打Boss或AI炼金造出的传奇武器穿在木偶架上陈列展示",
    "color1": "#B07D62",
    "color2": "#ADB5BD",
    "shape": "armor"
  },
  "526": {
    "id": 526,
    "name": "露天温泉石灯笼",
    "category": "3.8 工坊与房间家具",
    "subCategory": "1×1",
    "recipe": "温泉石×3+魔晶簇×1",
    "tags": [
      "照明",
      "温泉"
    ],
    "value": 80,
    "desc": "摆在温泉池边激活【绯樱露天温泉馆】识别（泡澡获20分钟HP上限+30%）",
    "color1": "#BDC3C7",
    "color2": "#FFB7C5",
    "shape": "lamp"
  },
  "527": {
    "id": 527,
    "name": "复古黑胶留声机",
    "category": "3.8 工坊与房间家具",
    "subCategory": "1×1",
    "recipe": "黄铜锭×2+樱木板×2",
    "tags": [
      "音乐",
      "留声机"
    ],
    "value": 95,
    "desc": "播放已录制的八音盒曲目或Boss战激昂交响曲",
    "color1": "#F39C12",
    "color2": "#A65E6E",
    "shape": "horn"
  },
  "528": {
    "id": 528,
    "name": "三层许愿音乐喷泉",
    "category": "3.8 工坊与房间家具",
    "subCategory": "3×3",
    "recipe": "温泉石×12+星辰碎片×2",
    "tags": [
      "地标",
      "天气"
    ],
    "value": 260,
    "desc": "小镇广场地标；投掷露水可许愿改变全岛天气（召唤彩虹或流星雨夜）",
    "color1": "#E8EEF1",
    "color2": "#4CC9F0",
    "shape": "fountain"
  },
  "529": {
    "id": 529,
    "name": "牧场动物自动饲育槽",
    "category": "3.8 工坊与房间家具",
    "subCategory": "2×1",
    "recipe": "松木板×4+黄金小麦×4",
    "tags": [
      "牧场",
      "饲育"
    ],
    "value": 65,
    "desc": "【生态牧场】识别件；圈养的云朵绵羊与水豚自动进食并每日产出毛团",
    "color1": "#D4A373",
    "color2": "#F4A261",
    "shape": "table"
  },
  "530": {
    "id": 530,
    "name": "游乐园旋转木马",
    "category": "3.8 工坊与房间家具",
    "subCategory": "3×3",
    "recipe": "樱木板×15+齿轮×6",
    "tags": [
      "游乐场",
      "木马"
    ],
    "value": 240,
    "desc": "通电后伴随八音盒旋律旋转，最多支持6名玩家同时骑乘拍照",
    "color1": "#FF758F",
    "color2": "#FFD166",
    "shape": "crown"
  },
  "531": {
    "id": 531,
    "name": "Boss荣耀战利品金雕像",
    "category": "3.8 工坊与房间家具",
    "subCategory": "2×2",
    "recipe": "击败任意群系Boss掉落",
    "tags": [
      "荣誉",
      "雕像"
    ],
    "value": 300,
    "desc": "在小镇广场竖立已被全房击败的Boss纯金Q版雕像并领取每日祝福",
    "color1": "#F39C12",
    "color2": "#FEF9E7",
    "shape": "trophy"
  },
  "532": {
    "id": 532,
    "name": "拳击测力稻草人靶",
    "category": "3.8 工坊与房间家具",
    "subCategory": "1×1",
    "recipe": "黄金小麦×4+暖松原木×2",
    "tags": [
      "训练",
      "木桩"
    ],
    "value": 45,
    "desc": "被武器或技能攻击时实时飘出伤害数字与秒伤(DPS)统计",
    "color1": "#E9C46A",
    "color2": "#8D5B4C",
    "shape": "character"
  },
  "533": {
    "id": 533,
    "name": "换装与词条重铸魔镜",
    "category": "3.8 工坊与房间家具",
    "subCategory": "1×1",
    "recipe": "琉璃板×2+魔晶簇×2",
    "tags": [
      "重铸",
      "换装"
    ],
    "value": 110,
    "desc": "消耗梦境露水为武器与护甲洗练随机属性词条，或更换时装外观",
    "color1": "#9B5DE5",
    "color2": "#CAF0F8",
    "shape": "glass"
  },
  "534": {
    "id": 534,
    "name": "迎宾点赞留言信箱",
    "category": "3.8 工坊与房间家具",
    "subCategory": "1×1",
    "recipe": "松木板×3+绯红染料×1",
    "tags": [
      "社交",
      "信箱"
    ],
    "value": 45,
    "desc": "立在岛屿码头，供来访或离线接力的好友留下贴纸贺卡与礼物",
    "color1": "#EF233C",
    "color2": "#F8F9FA",
    "shape": "chest"
  },
  "535": {
    "id": 535,
    "name": "岛主领地守护图腾",
    "category": "3.8 工坊与房间家具",
    "subCategory": "2×2",
    "recipe": "圆石×10+魔晶簇×4",
    "tags": [
      "权限",
      "护盾"
    ],
    "value": 150,
    "desc": "管理全房间权限矩阵，并开启/关闭城镇安全区免怪侵扰护盾",
    "color1": "#4A47A3",
    "color2": "#00F5D4",
    "shape": "totem"
  },
  "536": {
    "id": 536,
    "name": "【AI核心】万物奇想炼金炉",
    "category": "3.8 工坊与房间家具",
    "subCategory": "2×2",
    "recipe": "秘银锭×4+魔晶×4+露水×2",
    "tags": [
      "AI造物",
      "炼金"
    ],
    "value": 280,
    "desc": "自由放入任意2~4件非蓝图物品，调用大模型+数学算法生成全新奇物！",
    "color1": "#7209B7",
    "color2": "#06D6A0",
    "shape": "alchemy"
  },
  "537": {
    "id": 537,
    "name": "全服奇物发现博物架",
    "category": "3.8 工坊与房间家具",
    "subCategory": "2×1",
    "recipe": "樱木板×4+琉璃板×2",
    "tags": [
      "展示",
      "首创"
    ],
    "value": 120,
    "desc": "自动陈列本房间玩家【全服首次合成】的AI造物并展示冠名证书",
    "color1": "#D88C9A",
    "color2": "#90E0EF",
    "shape": "table"
  },
  "601": {
    "id": 601,
    "name": "暖心甜莓果茶",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "饮品料理",
    "recipe": "露水甜莓×2",
    "tags": [
      "料理",
      "回血"
    ],
    "value": 25,
    "desc": "立即恢复40 HP，移动速度+15%，持续10分钟",
    "color1": "#E63946",
    "color2": "#FFE5EC",
    "shape": "cup"
  },
  "602": {
    "id": 602,
    "name": "黄金麦香厚吐司",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "基础料理",
    "recipe": "麦香精面粉×2",
    "tags": [
      "料理",
      "体力"
    ],
    "value": 32,
    "desc": "最大生命值+30，伐木与采矿速度+20%，持续10分钟",
    "color1": "#F4A261",
    "color2": "#FFF3B0",
    "shape": "bread"
  },
  "603": {
    "id": 603,
    "name": "绯樱蜜桃果酱派",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "进阶料理",
    "recipe": "面粉×2+蜜桃×2+果酱×1",
    "tags": [
      "料理",
      "高爆率"
    ],
    "value": 75,
    "desc": "暴击率+15%，采集与打怪掉落物数量有35%几率翻倍",
    "color1": "#FF758F",
    "color2": "#F4A261",
    "shape": "pie"
  },
  "604": {
    "id": 604,
    "name": "星光萤火蘑菇汤",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "大锅汤品",
    "recipe": "夜光菌木×1+跳跳菇×2",
    "tags": [
      "汤品",
      "夜光"
    ],
    "value": 85,
    "desc": "全房饮用者全身散发柔和夜光，跳跃高度+50%且免疫跌落眩晕",
    "color1": "#4CC9F0",
    "color2": "#7209B7",
    "shape": "bowl"
  },
  "605": {
    "id": 605,
    "name": "大力水手海鲜烩",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "大锅汤品",
    "recipe": "鲜鱼×2+小麦×2+甜莓×2",
    "tags": [
      "汤品",
      "怪力"
    ],
    "value": 95,
    "desc": "近战攻击力+25%，举起队友或炸弹果时移速不衰减且投掷距离+3格",
    "color1": "#3A86FF",
    "color2": "#FF9F1C",
    "shape": "bowl"
  },
  "606": {
    "id": 606,
    "name": "龙息爆辣烤肉排",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "狩猎料理",
    "recipe": "野味肉块×2+爆裂火椒×2",
    "tags": [
      "料理",
      "火焰"
    ],
    "value": 90,
    "desc": "每次武器攻击附带15点火焰灼烧伤害，且免疫冰冻状态",
    "color1": "#D90429",
    "color2": "#8D5B4C",
    "shape": "meat"
  },
  "607": {
    "id": 607,
    "name": "喷火彩虹屁咖喱(恶作剧)",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "整蛊料理",
    "recipe": "大汤锅混入爆裂火椒×2",
    "tags": [
      "整蛊",
      "彩虹屁"
    ],
    "value": 88,
    "desc": "加攻25%同时，每走三步喷出一串彩虹火苗向前失控冲刺2格",
    "color1": "#FF006E",
    "color2": "#FFBE0B",
    "shape": "bowl"
  },
  "608": {
    "id": 608,
    "name": "小肥鸡咯咯浓汤(恶作剧)",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "整蛊料理",
    "recipe": "大汤锅混入幻彩变身菇×1",
    "tags": [
      "整蛊",
      "变肥鸡"
    ],
    "value": 92,
    "desc": "全房喝汤的人集体变成圆滚滚的小肥鸡60秒，可用鸡喙集体啄Boss",
    "color1": "#FFD166",
    "color2": "#9B5DE5",
    "shape": "bowl"
  },
  "609": {
    "id": 609,
    "name": "气球肚皮漂浮饮(恶作剧)",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "整蛊料理",
    "recipe": "大汤锅混入云朵棉花×2",
    "tags": [
      "整蛊",
      "低重力"
    ],
    "value": 80,
    "desc": "角色肚子变圆、重力降低70%，轻轻一跳就能飘在半空躲地面围攻",
    "color1": "#BDE0FE",
    "color2": "#FFFFFF",
    "shape": "cup"
  },
  "610": {
    "id": 610,
    "name": "滑溜溜溜冰奶昔(恶作剧)",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "整蛊料理",
    "recipe": "大汤锅混入滑溜香蕉×2",
    "tags": [
      "整蛊",
      "全员滑冰"
    ],
    "value": 85,
    "desc": "脚底自带滑冰效果(μ=0.96)，全队边滑冰边砍Boss场面极其欢乐",
    "color1": "#FFBE0B",
    "color2": "#90E0EF",
    "shape": "cup"
  },
  "611": {
    "id": 611,
    "name": "大嗓门回声果冻(恶作剧)",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "整蛊料理",
    "recipe": "大汤锅混入弹簧跳跳菇×3",
    "tags": [
      "整蛊",
      "八音步"
    ],
    "value": 82,
    "desc": "聊天文字放大抖动，且每次挥剑和走路都发出清脆八音盒音效",
    "color1": "#06D6A0",
    "color2": "#FF595E",
    "shape": "slime_ball"
  },
  "612": {
    "id": 612,
    "name": "冰爽薄荷净化饮",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "战斗药饮",
    "recipe": "冰晶薄荷×2+甜莓×1",
    "tags": [
      "药饮",
      "解控"
    ],
    "value": 70,
    "desc": "立即恢复80 HP并解除滑倒、中毒、变身、灼烧等一切负面状态",
    "color1": "#00F5D4",
    "color2": "#FFFFFF",
    "shape": "cup"
  },
  "613": {
    "id": 613,
    "name": "庆典三层奶油蛋糕",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "宴会料理",
    "recipe": "面粉×4+甜莓×4+蜂蜜×2",
    "tags": [
      "宴会",
      "经验"
    ],
    "value": 150,
    "desc": "摆在地上供8人分食，全队获得20分钟经验获取+30%增益",
    "color1": "#FFFFFF",
    "color2": "#FF758F",
    "shape": "pie"
  },
  "614": {
    "id": 614,
    "name": "森林百果驯兽饼干",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "驯养道具",
    "recipe": "面粉×1+甜莓×2+蜂蜜×1",
    "tags": [
      "驯养",
      "宠物"
    ],
    "value": 65,
    "desc": "喂给野生温顺动物或残血精英小怪，直接将其驯化为跟随宠物",
    "color1": "#F4A261",
    "color2": "#E63946",
    "shape": "bread"
  },
  "615": {
    "id": 615,
    "name": "森灵最爱彩虹糖",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "森灵饲料",
    "recipe": "皇家蜂蜜×1+甜莓×2",
    "tags": [
      "饲料",
      "加速"
    ],
    "value": 60,
    "desc": "喂给波波森灵后，该森灵在30分钟内收菜与协助捡战利品效率翻倍",
    "color1": "#FF006E",
    "color2": "#00BBF9",
    "shape": "berry"
  },
  "616": {
    "id": 616,
    "name": "田园宽檐大草帽",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "角色头饰",
    "recipe": "柔韧风草×4",
    "tags": [
      "头饰",
      "防晒"
    ],
    "value": 35,
    "desc": "防御+2，阳光下阴影柔和",
    "color1": "#E9C46A",
    "color2": "#E07A5F",
    "shape": "helmet"
  },
  "617": {
    "id": 617,
    "name": "矿工探照灯泡帽",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "功能头饰",
    "recipe": "黄铜锭×2+魔晶簇×1",
    "tags": [
      "头饰",
      "照明"
    ],
    "value": 85,
    "desc": "防御+5，在地下溶洞或夜晚自动照亮角色正前方6格扇形区域",
    "color1": "#FFBE0B",
    "color2": "#4CC9F0",
    "shape": "helmet"
  },
  "618": {
    "id": 618,
    "name": "小黄鸭游泳圈",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "功能腰饰",
    "recipe": "果冻胶×2+琥珀染料×1",
    "tags": [
      "腰饰",
      "水战"
    ],
    "value": 75,
    "desc": "穿戴后可在Z=-1深水区自由游泳并挥剑水战",
    "color1": "#FFD166",
    "color2": "#FB8500",
    "shape": "ring"
  },
  "619": {
    "id": 619,
    "name": "溜冰鞋与护膝套",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "功能鞋饰",
    "recipe": "寒铁锭×2+云朵布×1",
    "tags": [
      "鞋饰",
      "防滑"
    ],
    "value": 90,
    "desc": "站在【镜面极滑冰砖】上不再失控打滑且冰面移速+40%（溜Boss神器）",
    "color1": "#FFFFFF",
    "color2": "#3A86FF",
    "shape": "boots"
  },
  "620": {
    "id": 620,
    "name": "青蛙弹簧跳跳鞋",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "功能鞋饰",
    "recipe": "跳跳菇×2+云朵布×2",
    "tags": [
      "鞋饰",
      "跳高"
    ],
    "value": 95,
    "desc": "平地可直接跳上Z=1一层高台，且踩在怪物头顶触发踩头二段跳",
    "color1": "#58A65C",
    "color2": "#FF595E",
    "shape": "boots"
  },
  "621": {
    "id": 621,
    "name": "云朵天使小翅膀",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "背饰时装",
    "recipe": "云朵布×6+星辰碎片×1",
    "tags": [
      "背饰",
      "滑翔"
    ],
    "value": 180,
    "desc": "免疫高处坠落眩晕，支持在空中滑翔跨越深渊",
    "color1": "#FFFFFF",
    "color2": "#BDE0FE",
    "shape": "wings"
  },
  "622": {
    "id": 622,
    "name": "呆萌鲨鱼鳍泳帽",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "搞怪头饰",
    "recipe": "云朵布×3+星夜染料×1",
    "tags": [
      "头饰",
      "泳速"
    ],
    "value": 80,
    "desc": "水中移速+30%，游泳时只露出一截鲨鱼背鳍吓唬钓鱼的朋友",
    "color1": "#4EA8DE",
    "color2": "#FFFFFF",
    "shape": "helmet"
  },
  "623": {
    "id": 623,
    "name": "摇晃弹簧大便帽",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "搞怪头饰",
    "recipe": "红黏土×2+跳跳菇×1",
    "tags": [
      "头饰",
      "嘲讽"
    ],
    "value": 65,
    "desc": "跑步时头顶软胶造型夸张摇晃，吸引野生果冻怪追着你跑",
    "color1": "#8D5B4C",
    "color2": "#F4A261",
    "shape": "helmet"
  },
  "624": {
    "id": 624,
    "name": "招财进宝猫耳箍",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "社交头饰",
    "recipe": "云朵布×2+曜金矿×1",
    "tags": [
      "头饰",
      "幸运"
    ],
    "value": 110,
    "desc": "击败野生动物时金币与稀有材料掉落率+15%",
    "color1": "#FF99C8",
    "color2": "#FFD166",
    "shape": "helmet"
  },
  "625": {
    "id": 625,
    "name": "皇家金皇冠(永久)",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "荣誉头饰",
    "recipe": "金皇冠大逃杀获胜5次",
    "tags": [
      "头饰",
      "皇冠"
    ],
    "value": 250,
    "desc": "全属性+5%，头顶常驻闪亮星芒特效，波波森灵见到你会行礼",
    "color1": "#FFD166",
    "color2": "#EF233C",
    "shape": "crown"
  },
  "626": {
    "id": 626,
    "name": "金牌大厨高高帽",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "专精头饰",
    "recipe": "欢宴大厨专精5级解锁",
    "tags": [
      "头饰",
      "大厨"
    ],
    "value": 120,
    "desc": "烹饪出的料理持续时间翻倍",
    "color1": "#FFFFFF",
    "color2": "#E63946",
    "shape": "helmet"
  },
  "627": {
    "id": 627,
    "name": "发条目镜工程师帽",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "专精头饰",
    "recipe": "魔能工程师专精5级解锁",
    "tags": [
      "头饰",
      "工程"
    ],
    "value": 120,
    "desc": "角色放置的【自动泡泡连弩炮台】射速+35%，常驻显示地下电线",
    "color1": "#D4AC0D",
    "color2": "#4CC9F0",
    "shape": "helmet"
  },
  "628": {
    "id": 628,
    "name": "繁花鹿角园艺冠",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "专精头饰",
    "recipe": "生态园艺师专精5级解锁",
    "tags": [
      "头饰",
      "园艺"
    ],
    "value": 120,
    "desc": "可同时携带2只已驯服的野生动物宠物出战，走过草地绽放小花",
    "color1": "#58A65C",
    "color2": "#FF758F",
    "shape": "helmet"
  },
  "629": {
    "id": 629,
    "name": "贝雷帽与调色板",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "专精头饰",
    "recipe": "绘本画师专精5级解锁",
    "tags": [
      "头饰",
      "画师"
    ],
    "value": 120,
    "desc": "使用染色喷枪时不消耗染料",
    "color1": "#9B5DE5",
    "color2": "#FFD166",
    "shape": "helmet"
  },
  "630": {
    "id": 630,
    "name": "自定义像素印花披风",
    "category": "3.9 料理与搞怪时装",
    "subCategory": "UGC背饰",
    "recipe": "云朵布×4+幻彩蚕丝×2",
    "tags": [
      "背饰",
      "UGC"
    ],
    "value": 140,
    "desc": "防御+8，背面实时展示玩家手绘的16×16像素图案（战队同款披风）",
    "color1": "#3A86FF",
    "color2": "#FF006E",
    "shape": "cloak"
  },
  "701": {
    "id": 701,
    "name": "鲜嫩野味肉块",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "狩猎掉落",
    "recipe": "击杀野猪/沙蝎等掉落",
    "tags": [
      "食材",
      "肉类"
    ],
    "value": 22,
    "desc": "烤肉与熬制加攻大锅汤的核心肉材",
    "color1": "#E63946",
    "color2": "#F8F9FA",
    "shape": "meat"
  },
  "702": {
    "id": 702,
    "name": "坚韧野兽毛皮",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "狩猎掉落",
    "recipe": "击杀野猪/穿山甲掉落",
    "tags": [
      "皮革",
      "护甲"
    ],
    "value": 28,
    "desc": "缝制轻便皮甲、猎人箭袋与战鼓鼓面",
    "color1": "#8D5B4C",
    "color2": "#D4A373",
    "shape": "cloth"
  },
  "703": {
    "id": 703,
    "name": "河狸钢牙切片",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "狩猎掉落",
    "recipe": "击败淘气造坝河狸掉落",
    "tags": [
      "锐器",
      "破甲"
    ],
    "value": 45,
    "desc": "锻造高破甲锯齿武器与高级伐木锯",
    "color1": "#F8F9FA",
    "color2": "#E09F3E",
    "shape": "crystal"
  },
  "704": {
    "id": 704,
    "name": "果冻王凝露皇冠",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "Boss遗物",
    "recipe": "击败【果冻国王】必掉",
    "tags": [
      "Boss遗物",
      "高弹"
    ],
    "value": 220,
    "desc": "锻造果冻王传奇武器与高弹果冻护甲的核心遗物",
    "color1": "#FFD166",
    "color2": "#FF595E",
    "shape": "crown"
  },
  "705": {
    "id": 705,
    "name": "千年绯樱妖木心",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "Boss遗物",
    "recipe": "击败【千年垂枝妖狐】必掉",
    "tags": [
      "Boss遗物",
      "治愈"
    ],
    "value": 240,
    "desc": "蕴含生机魔力，用于锻造落英法杖与全团回血图腾",
    "color1": "#FF758F",
    "color2": "#64FFDA",
    "shape": "star"
  },
  "706": {
    "id": 706,
    "name": "深渊紫晶重甲壳",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "Boss遗物",
    "recipe": "击败【深渊晶甲巨蟹】必掉",
    "tags": [
      "Boss遗物",
      "反伤"
    ],
    "value": 260,
    "desc": "坚不可摧的紫晶壳，用于锻造反伤重盾与破城重锤",
    "color1": "#7209B7",
    "color2": "#C77DFF",
    "shape": "shield"
  },
  "707": {
    "id": 707,
    "name": "黄金法老毒尾针",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "Boss遗物",
    "recipe": "击败【黄金沙暴法老蝎】必掉",
    "tags": [
      "Boss遗物",
      "剧毒"
    ],
    "value": 280,
    "desc": "用于锻造附带流沙漩涡与剧毒词条的传奇刺剑与长枪",
    "color1": "#F39C12",
    "color2": "#06D6A0",
    "shape": "sword"
  },
  "708": {
    "id": 708,
    "name": "永动发条太阳核",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "Boss遗物",
    "recipe": "击败【发条时间巨像】必掉",
    "tags": [
      "Boss遗物",
      "时停"
    ],
    "value": 350,
    "desc": "终极魔导动力源，用于锻造磁暴齿轮炮与时停力场",
    "color1": "#FFB703",
    "color2": "#00F5D4",
    "shape": "gear"
  },
  "709": {
    "id": 709,
    "name": "萤光蝙蝠超声波翼",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "狩猎掉落",
    "recipe": "击败溶洞萤光蝙蝠掉落",
    "tags": [
      "飞行",
      "声波"
    ],
    "value": 55,
    "desc": "制作吸血披风、夜间暴击饰品与声呐菇菇帽",
    "color1": "#5A189A",
    "color2": "#4CC9F0",
    "shape": "wings"
  },
  "710": {
    "id": 710,
    "name": "熔岩炽热火灵核",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "狩猎掉落",
    "recipe": "击败地下熔岩火灵掉落",
    "tags": [
      "火焰",
      "高温"
    ],
    "value": 75,
    "desc": "免燃料永久加热高炉，或锻造烈焰附魔武器",
    "color1": "#D90429",
    "color2": "#FFBE0B",
    "shape": "star"
  },
  "711": {
    "id": 711,
    "name": "初心冒险者木剑",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "近战轻剑",
    "recipe": "暖松原木×4+风草绳×1",
    "tags": [
      "武器",
      "轻剑"
    ],
    "value": 35,
    "desc": "ATK+12；普攻三连挥砍，主动技[Q]旋风斩击退周围小怪",
    "color1": "#B07D62",
    "color2": "#8D5B4C",
    "shape": "sword"
  },
  "712": {
    "id": 712,
    "name": "寒铁骑士阔剑",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "近战重剑",
    "recipe": "寒铁锭×5+野兽毛皮×2",
    "tags": [
      "武器",
      "重剑"
    ],
    "value": 110,
    "desc": "ATK+28；主动技[Q]破盾重劈：跃起猛劈地面震晕2×3格内敌人1.5秒",
    "color1": "#5C677D",
    "color2": "#CBD5E1",
    "shape": "sword"
  },
  "713": {
    "id": 713,
    "name": "黑曜石烈焰巨剑",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "近战重剑",
    "recipe": "黑曜石×6+熔岩火灵核×2",
    "tags": [
      "武器",
      "火焰"
    ],
    "value": 210,
    "desc": "ATK+48；自带火焰刀光，主动技[Q]熔岩裂地斩发出6格远火浪",
    "color1": "#2C223E",
    "color2": "#FF595E",
    "shape": "sword"
  },
  "714": {
    "id": 714,
    "name": "秘银疾风双刃",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "近战双刀",
    "recipe": "秘银锭×4+河狸钢牙×2",
    "tags": [
      "武器",
      "双刀"
    ],
    "value": 185,
    "desc": "ATK+38；极速乱舞，主动技[Q]幻影突袭穿梭5格并抓起眩晕小怪扔出",
    "color1": "#2EC4B6",
    "color2": "#FFFFFF",
    "shape": "sword"
  },
  "715": {
    "id": 715,
    "name": "翠玉青竹连珠弓",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "远程猎弓",
    "recipe": "翠玉青竹×4+风草绳×2",
    "tags": [
      "武器",
      "猎弓"
    ],
    "value": 65,
    "desc": "ATK+18；移动蓄力射击，主动技[Q]三连散射扇形射出3支竹箭",
    "color1": "#58A65C",
    "color2": "#E9C46A",
    "shape": "bow"
  },
  "716": {
    "id": 716,
    "name": "秘银追星神弓",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "远程猎弓",
    "recipe": "秘银锭×4+蚕丝×3+魔晶×2",
    "tags": [
      "武器",
      "星箭"
    ],
    "value": 195,
    "desc": "ATK+42；箭矢穿透2目标，主动技[Q]箭雨天降在4×4区域降下星光箭雨",
    "color1": "#3A86FF",
    "color2": "#70D6FF",
    "shape": "bow"
  },
  "717": {
    "id": 717,
    "name": "晨露新芽魔杖",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "元素法杖",
    "recipe": "夜光菌木×3+魔晶簇×2",
    "tags": [
      "武器",
      "治愈"
    ],
    "value": 85,
    "desc": "MATK+20；追踪星光弹，主动技[Q]治愈春风圈为周围5格队友恢复60 HP",
    "color1": "#58A65C",
    "color2": "#FF758F",
    "shape": "wand"
  },
  "718": {
    "id": 718,
    "name": "极光星辰魔导师杖",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "元素法杖",
    "recipe": "星辰碎片×3+秘银锭×3",
    "tags": [
      "武器",
      "陨星"
    ],
    "value": 260,
    "desc": "MATK+52；主动技[Q]陨石星落召唤Q版彩色流星砸向怪群造成巨额伤害",
    "color1": "#7209B7",
    "color2": "#FFD166",
    "shape": "wand"
  },
  "719": {
    "id": 719,
    "name": "【Boss】果冻王弹跳皇冠锤",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "传奇重锤",
    "recipe": "果冻王皇冠×1+寒铁锭×4",
    "tags": [
      "传奇",
      "召唤"
    ],
    "value": 290,
    "desc": "ATK+40,击退+200%；[Q]泰山压顶跃至Z=3猛砸地面召唤4只友好小果冻助战",
    "color1": "#4EA8DE",
    "color2": "#FFD166",
    "shape": "hammer"
  },
  "720": {
    "id": 720,
    "name": "【Boss】绯月落英吹雪扇",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "传奇法器",
    "recipe": "绯樱妖木心×1+樱木板×4",
    "tags": [
      "传奇",
      "护盾"
    ],
    "value": 310,
    "desc": "MATK+46；扇出三道樱花风刃，[Q]落英幻境赋予全队5秒花瓣护盾与移速+40%",
    "color1": "#FF758F",
    "color2": "#FFE5EC",
    "shape": "fan"
  },
  "721": {
    "id": 721,
    "name": "【Boss】深渊紫晶破城盾锤",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "传奇盾武",
    "recipe": "紫晶重甲壳×1+黑曜石×4",
    "tags": [
      "传奇",
      "反弹"
    ],
    "value": 330,
    "desc": "ATK+45,DEF+35；按住技能架起紫晶盾将Boss冲撞与弹幕100%反弹回去",
    "color1": "#7209B7",
    "color2": "#E0AAFF",
    "shape": "hammer"
  },
  "722": {
    "id": 722,
    "name": "【Boss】法老流沙毒刺枪",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "传奇长枪",
    "recipe": "法老毒尾针×1+曜金矿×4",
    "tags": [
      "传奇",
      "聚怪"
    ],
    "value": 350,
    "desc": "ATK+50；[Q]流沙星璇在枪尖生成流沙漩涡把周围5格怪物全部聚拢",
    "color1": "#F39C12",
    "color2": "#2A9D8F",
    "shape": "sword"
  },
  "723": {
    "id": 723,
    "name": "【Boss】克洛诺斯磁暴齿轮炮",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "传奇重炮",
    "recipe": "发条太阳核×1+齿轮×8",
    "tags": [
      "传奇",
      "时停"
    ],
    "value": 420,
    "desc": "ATK+65；发射弹射电弧齿轮，[Q]时间凝滞力场冻结6×6圈内所有怪物与弹幕3秒",
    "color1": "#D4AC0D",
    "color2": "#00F5D4",
    "shape": "gun"
  },
  "724": {
    "id": 724,
    "name": "森之游侠软皮甲",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "胸部护甲",
    "recipe": "野兽毛皮×4+风草绳×2",
    "tags": [
      "护甲",
      "闪避"
    ],
    "value": 65,
    "desc": "HP+40, DEF+8, 闪避+10%；翻滚冷却缩减20%",
    "color1": "#8D5B4C",
    "color2": "#58A65C",
    "shape": "armor"
  },
  "725": {
    "id": 725,
    "name": "寒铁重装骑士甲",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "胸部护甲",
    "recipe": "寒铁锭×6+云朵布×2",
    "tags": [
      "护甲",
      "重甲"
    ],
    "value": 140,
    "desc": "HP+100, DEF+22；受击硬直减半，前排顶Boss吸引仇恨必备",
    "color1": "#5C677D",
    "color2": "#F39C12",
    "shape": "armor"
  },
  "726": {
    "id": 726,
    "name": "秘银星辉魔导袍",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "胸部护甲",
    "recipe": "秘银锭×4+幻彩蚕丝×4",
    "tags": [
      "护甲",
      "法袍"
    ],
    "value": 180,
    "desc": "HP+60, DEF+14, 冷却-25%；释放治疗或护盾技能范围扩大50%",
    "color1": "#3A0CA3",
    "color2": "#4CC9F0",
    "shape": "armor"
  },
  "727": {
    "id": 727,
    "name": "【Boss】果冻王Q弹软糖甲",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "传奇护甲",
    "recipe": "果冻王皇冠×1+果冻胶×6",
    "tags": [
      "传奇",
      "弹反"
    ],
    "value": 280,
    "desc": "HP+120, DEF+18；受到近战攻击时直接把攻击你的怪物像皮球一样弹飞4格",
    "color1": "#00BBF9",
    "color2": "#70D6FF",
    "shape": "armor"
  },
  "728": {
    "id": 728,
    "name": "【Boss】紫晶荆棘反伤甲",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "传奇护甲",
    "recipe": "紫晶重甲壳×1+寒铁锭×6",
    "tags": [
      "传奇",
      "反伤"
    ],
    "value": 320,
    "desc": "HP+160, DEF+32；减免30%伤害并将所受伤害的150%化作紫晶尖刺反伤周围",
    "color1": "#7209B7",
    "color2": "#FF006E",
    "shape": "armor"
  },
  "729": {
    "id": 729,
    "name": "夜影吸血蝙蝠斗篷",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "奇物背饰",
    "recipe": "蝙蝠超声波翼×2+云朵布×3",
    "tags": [
      "背饰",
      "吸血"
    ],
    "value": 150,
    "desc": "移速+10%；每次武器或技能命中野生怪物时恢复自身3 HP",
    "color1": "#2C223E",
    "color2": "#EF233C",
    "shape": "cloak"
  },
  "730": {
    "id": 730,
    "name": "疾风二段跳羽戒",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "奇物饰品",
    "recipe": "星辰碎片×1+秘银锭×2",
    "tags": [
      "饰品",
      "二段跳"
    ],
    "value": 190,
    "desc": "允许角色在空中额外进行一次翻滚冲刺或二段跳，越过Boss激光环",
    "color1": "#06D6A0",
    "color2": "#FFD166",
    "shape": "ring"
  },
  "731": {
    "id": 731,
    "name": "同伴共鸣友爱徽章",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "团战饰品",
    "recipe": "曜金矿×2+梦境露水×3",
    "tags": [
      "饰品",
      "团战"
    ],
    "value": 160,
    "desc": "周围8格内每有1名队友，自身攻防各提升+5%（最高叠加至+40%）",
    "color1": "#FF006E",
    "color2": "#FFD166",
    "shape": "star"
  },
  "732": {
    "id": 732,
    "name": "甜莓瞬回生命药水",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "战斗消耗",
    "recipe": "空药水瓶×1+甜莓果酱×1",
    "tags": [
      "药水",
      "群疗"
    ],
    "value": 45,
    "desc": "饮用瞬间恢复100 HP，也可直接扔向残血队友触发范围溅射治疗",
    "color1": "#E63946",
    "color2": "#FFFFFF",
    "shape": "potion"
  },
  "733": {
    "id": 733,
    "name": "复苏天使羽毛笔",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "团战消耗",
    "recipe": "云朵棉花×2+梦境露水×1",
    "tags": [
      "救援",
      "复活"
    ],
    "value": 70,
    "desc": "扔向变成【幽灵泡泡】倒地的队友，隔着6格远瞬间将其满血复活并赋予无敌",
    "color1": "#FFFFFF",
    "color2": "#FFD166",
    "shape": "wings"
  },
  "734": {
    "id": 734,
    "name": "【祭品】皇家十倍甜莓布丁",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "Boss召唤",
    "recipe": "甜莓×20+蜂蜜×5+面粉×5",
    "tags": [
      "祭品",
      "草甸Boss"
    ],
    "value": 120,
    "desc": "放在草甸祭坛上，召唤【果冻国王·波波大帝】",
    "color1": "#FF595E",
    "color2": "#FFF3B0",
    "shape": "pie"
  },
  "735": {
    "id": 735,
    "name": "【祭品】黄金香脆松木图腾",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "Boss召唤",
    "recipe": "原木×30+蜜桃×10+黄铜×4",
    "tags": [
      "祭品",
      "河谷Boss"
    ],
    "value": 150,
    "desc": "放在河谷祭坛上，召唤【巨型机甲河狸·大坝粉碎者】",
    "color1": "#D4AC0D",
    "color2": "#8D5B4C",
    "shape": "totem"
  },
  "736": {
    "id": 736,
    "name": "【祭品】绯月千年祈愿御币",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "Boss召唤",
    "recipe": "樱木×20+蚕丝×5+露水×5",
    "tags": [
      "祭品",
      "绯樱Boss"
    ],
    "value": 180,
    "desc": "放在绯樱高地神社祭坛上，召唤【千年垂枝妖狐·绯月】",
    "color1": "#FF758F",
    "color2": "#FFFFFF",
    "shape": "scroll"
  },
  "737": {
    "id": 737,
    "name": "【祭品】共鸣深渊紫晶核",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "Boss召唤",
    "recipe": "魔晶簇×15+寒铁锭×10",
    "tags": [
      "祭品",
      "溶洞Boss"
    ],
    "value": 220,
    "desc": "放在地下溶洞核心祭坛上，召唤【深渊晶甲巨蟹·克拉肯】",
    "color1": "#7209B7",
    "color2": "#4CC9F0",
    "shape": "crystal"
  },
  "738": {
    "id": 738,
    "name": "【祭品】太阳神金甲虫圣杯",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "Boss召唤",
    "recipe": "曜金×10+石英×20+火椒×10",
    "tags": [
      "祭品",
      "绿洲Boss"
    ],
    "value": 260,
    "desc": "放在沙漠金字塔祭坛上，召唤【黄金沙暴法老蝎】",
    "color1": "#F39C12",
    "color2": "#D90429",
    "shape": "trophy"
  },
  "739": {
    "id": 739,
    "name": "【祭品】皇家焦糖彩虹姜饼屋",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "Boss召唤",
    "recipe": "威化木×20+果冻×10+蜂蜜×5",
    "tags": [
      "祭品",
      "甜点Boss"
    ],
    "value": 290,
    "desc": "放在甜点奇境祭坛上，召唤【暴食翻糖姜饼巨魔】",
    "color1": "#C68B59",
    "color2": "#FF99C8",
    "shape": "hut"
  },
  "740": {
    "id": 740,
    "name": "【祭品】星穹唤鲸八音海螺",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "Boss召唤",
    "recipe": "星辰碎片×8+云朵棉花×20",
    "tags": [
      "祭品",
      "云海Boss"
    ],
    "value": 340,
    "desc": "在浮空云海码头吹响，召唤【星穹幻彩云鲸】",
    "color1": "#00BBF9",
    "color2": "#FFD166",
    "shape": "horn"
  },
  "741": {
    "id": 741,
    "name": "【祭品】古老黄金上弦发条钥",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "Boss召唤",
    "recipe": "齿轮×20+秘银×10+黑曜石×10",
    "tags": [
      "祭品",
      "终极Boss"
    ],
    "value": 400,
    "desc": "插入发条遗迹中央钟盘，唤醒终极Boss【远古发条时间巨像】",
    "color1": "#FFB703",
    "color2": "#2C223E",
    "shape": "gear"
  },
  "742": {
    "id": 742,
    "name": "宠物牵引红丝带",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "驯养工具",
    "recipe": "幻彩蚕丝×2+绯红染料×1",
    "tags": [
      "驯养",
      "指令"
    ],
    "value": 55,
    "desc": "给已驯化动物系上蝴蝶结，命令其跟随出战、留守牧场或背8格物品",
    "color1": "#EF233C",
    "color2": "#FFCCD5",
    "shape": "spool"
  },
  "743": {
    "id": 743,
    "name": "云朵陆行鸟骑乘鞍",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "坐骑装备",
    "recipe": "野兽毛皮×4+黄铜锭×2",
    "tags": [
      "坐骑",
      "加速"
    ],
    "value": 95,
    "desc": "给驯服的【彩虹陆行鸟】或【滚石穿山甲】装上后直接骑乘狂奔(移速+60%)",
    "color1": "#8D5B4C",
    "color2": "#F39C12",
    "shape": "armor"
  },
  "744": {
    "id": 744,
    "name": "怪物图鉴照相机",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "收集工具",
    "recipe": "黄铜锭×2+琉璃板×2+魔晶×1",
    "tags": [
      "收集",
      "图鉴"
    ],
    "value": 110,
    "desc": "给野生动物或Boss拍照收录进全房图鉴，全房永久对该怪伤害+10%",
    "color1": "#343A40",
    "color2": "#4CC9F0",
    "shape": "compass"
  },
  "745": {
    "id": 745,
    "name": "怪物生态诱捕笼",
    "category": "3.10 武器护甲与战利品",
    "subCategory": "沙盒机关",
    "recipe": "寒铁锭×4+松木板×4",
    "tags": [
      "机关",
      "活捉"
    ],
    "value": 100,
    "desc": "装入甜莓诱饵活捉野生小怪，可连笼子一起抱回自己建的动物园展示",
    "color1": "#5C677D",
    "color2": "#B07D62",
    "shape": "chest"
  },
  "801": {
    "id": 801,
    "name": "造物建筑师 (Builder)",
    "category": "4.0 六大专精角色",
    "subCategory": "六大专精角色",
    "recipe": "初始可选/自由兼修",
    "tags": [
      "角色",
      "建筑师"
    ],
    "value": 100,
    "desc": "解锁斜屋顶、拱桥与【魔法描图卷轴】，框选复制建筑供全房接力盖楼",
    "color1": "#FFBE0B",
    "color2": "#3A86FF",
    "shape": "char_builder"
  },
  "802": {
    "id": 802,
    "name": "魔能工程师 (Tinkerer)",
    "category": "4.0 六大专精角色",
    "subCategory": "六大专精角色",
    "recipe": "初始可选/自由兼修",
    "tags": [
      "角色",
      "工程师"
    ],
    "value": 100,
    "desc": "解锁四色电线、八音盒砖、机械臂、蒸汽火车与游乐场计分传感器",
    "color1": "#E09F3E",
    "color2": "#5C677D",
    "shape": "char_tinkerer"
  },
  "803": {
    "id": 803,
    "name": "生态园艺师 (Botanist)",
    "category": "4.0 六大专精角色",
    "subCategory": "六大专精角色",
    "recipe": "初始可选/自由兼修",
    "tags": [
      "角色",
      "园艺师"
    ],
    "value": 100,
    "desc": "解锁挖渠引水、花卉杂交、波波森灵训导与携带2只驯服动物出战",
    "color1": "#58A65C",
    "color2": "#FF758F",
    "shape": "char_botanist"
  },
  "804": {
    "id": 804,
    "name": "欢宴大厨 (Chef)",
    "category": "4.0 六大专精角色",
    "subCategory": "六大专精角色",
    "recipe": "初始可选/自由兼修",
    "tags": [
      "角色",
      "大厨"
    ],
    "value": 100,
    "desc": "解锁【八人欢聚大汤锅】与恶作剧黑暗料理，料理持续时间翻倍",
    "color1": "#FFFFFF",
    "color2": "#E63946",
    "shape": "char_chef"
  },
  "805": {
    "id": 805,
    "name": "秘境探险家 (Explorer)",
    "category": "4.0 六大专精角色",
    "subCategory": "六大专精角色",
    "recipe": "初始可选/自由兼修",
    "tags": [
      "角色",
      "探险家"
    ],
    "value": 100,
    "desc": "解锁爆破冲击镐、遗迹探测仪与全房共享迷雾地图绘制",
    "color1": "#F4A261",
    "color2": "#4CC9F0",
    "shape": "char_explorer"
  },
  "806": {
    "id": 806,
    "name": "绘本画师 (Artisan)",
    "category": "4.0 六大专精角色",
    "subCategory": "六大专精角色",
    "recipe": "初始可选/自由兼修",
    "tags": [
      "角色",
      "画师"
    ],
    "value": 100,
    "desc": "解锁16×16像素画架、免燃料染色喷枪与自定义战队像素披风",
    "color1": "#9B5DE5",
    "color2": "#FF006E",
    "shape": "char_artisan"
  },
  "811": {
    "id": 811,
    "name": "云朵绵羊 (mob_sheep)",
    "category": "4.2 野生动物与怪物",
    "subCategory": "1.草甸·温顺可驯",
    "recipe": "Lv.1 / HP:60",
    "tags": [
      "温顺",
      "产羊毛"
    ],
    "value": 15,
    "desc": "喂黄金小麦可驯化回牧场每日剪云朵棉花，受惊像棉花糖弹跳",
    "color1": "#FFFFFF",
    "color2": "#FFE5D9",
    "shape": "mob_sheep"
  },
  "812": {
    "id": 812,
    "name": "甜莓果冻怪 (mob_slime)",
    "category": "4.2 野生动物与怪物",
    "subCategory": "1.草甸·淘气主动",
    "recipe": "Lv.2 / HP:90",
    "tags": [
      "果冻",
      "高弹"
    ],
    "value": 25,
    "desc": "优先偷吃地上的甜莓变大，掉落高弹果冻胶",
    "color1": "#06D6A0",
    "color2": "#E63946",
    "shape": "mob_slime"
  },
  "813": {
    "id": 813,
    "name": "冲锋森林野猪 (mob_boar)",
    "category": "4.2 野生动物与怪物",
    "subCategory": "1.草甸·敌对狩猎",
    "recipe": "Lv.4 / HP:180",
    "tags": [
      "冲锋",
      "野兽"
    ],
    "value": 45,
    "desc": "刨蹄蓄力1秒后直线冲锋6格，引它撞石墙或踩香蕉皮会自己撞晕3秒",
    "color1": "#6F4E37",
    "color2": "#F8F9FA",
    "shape": "mob_boar"
  },
  "814": {
    "id": 814,
    "name": "大尾花栗鼠 (mob_squirrel)",
    "category": "4.2 野生动物与怪物",
    "subCategory": "2.河谷·温顺可驯",
    "recipe": "Lv.2 / HP:50",
    "tags": [
      "温顺",
      "捡果子"
    ],
    "value": 20,
    "desc": "喂露水甜莓可驯化为帮玩家自动捡地上果子与木头的小跟班",
    "color1": "#E07A5F",
    "color2": "#F4A261",
    "shape": "mob_squirrel"
  },
  "815": {
    "id": 815,
    "name": "淘气造坝河狸 (mob_beaver)",
    "category": "4.2 野生动物与怪物",
    "subCategory": "2.河谷·淘气互动",
    "recipe": "Lv.5 / HP:220",
    "tags": [
      "偷木板",
      "筑坝"
    ],
    "value": 55,
    "desc": "偷偷抱走散落木板去河道筑坝；用充气大锤敲晕可夺回木头并获图纸",
    "color1": "#8D5B4C",
    "color2": "#D4A373",
    "shape": "mob_beaver"
  },
  "816": {
    "id": 816,
    "name": "铁钳河蟹 (mob_crab)",
    "category": "4.2 野生动物与怪物",
    "subCategory": "2.河谷·敌对狩猎",
    "recipe": "Lv.6 / HP:260",
    "tags": [
      "横行",
      "海鲜"
    ],
    "value": 65,
    "desc": "横向快速移动夹人；被举起丢进八人大汤锅直接变美味海鲜汤食材",
    "color1": "#E63946",
    "color2": "#FF9F1C",
    "shape": "mob_crab"
  },
  "817": {
    "id": 817,
    "name": "温泉卡皮巴拉 (mob_capybara)",
    "category": "4.2 野生动物与怪物",
    "subCategory": "3.绯樱·温顺神兽",
    "recipe": "Lv.5 / HP:300",
    "tags": [
      "水豚",
      "回血光环"
    ],
    "value": 50,
    "desc": "头顶橘子泡温泉情绪极稳，不可击杀，在它身边泡澡回血翻倍",
    "color1": "#F4A261",
    "color2": "#FF99C8",
    "shape": "mob_capybara"
  },
  "818": {
    "id": 818,
    "name": "幻叶小狸猫 (mob_tanuki)",
    "category": "4.2 野生动物与怪物",
    "subCategory": "3.绯樱·淘气互动",
    "recipe": "Lv.8 / HP:320",
    "tags": [
      "伪装",
      "变身"
    ],
    "value": 85,
    "desc": "顶树叶伪装成石灯笼或宝箱，靠近时跳出扔迷雾果再嬉笑逃跑",
    "color1": "#8D5B4C",
    "color2": "#58A65C",
    "shape": "mob_squirrel"
  },
  "819": {
    "id": 819,
    "name": "竹林剑客傀儡 (mob_samurai)",
    "category": "4.2 野生动物与怪物",
    "subCategory": "3.绯樱·敌对狩猎",
    "recipe": "Lv.10 / HP:450",
    "tags": [
      "格挡",
      "竹刀"
    ],
    "value": 110,
    "desc": "正面竹刀格挡，需两名玩家一前一后夹击或用火椒箭点燃它",
    "color1": "#58A65C",
    "color2": "#E9C46A",
    "shape": "char_builder"
  },
  "820": {
    "id": 820,
    "name": "提灯萤火蛙 (mob_frog)",
    "category": "4.2 野生动物与怪物",
    "subCategory": "4.溶洞·温顺可驯",
    "recipe": "Lv.8 / HP:150",
    "tags": [
      "移动光源",
      "捕虫"
    ],
    "value": 60,
    "desc": "背部散发蓝紫微光，驯化后带在身边可当地下溶洞移动照明灯",
    "color1": "#06D6A0",
    "color2": "#64FFDA",
    "shape": "mob_slime"
  },
  "821": {
    "id": 821,
    "name": "萤光音波蝠 (mob_bat)",
    "category": "4.2 野生动物与怪物",
    "subCategory": "4.溶洞·敌对狩猎",
    "recipe": "Lv.11 / HP:380",
    "tags": [
      "飞行",
      "声波"
    ],
    "value": 125,
    "desc": "俯冲发射环形音波，玩家敲响三角铁或音符砖可干扰声呐使其坠地",
    "color1": "#7209B7",
    "color2": "#FF99C8",
    "shape": "mob_bat"
  },
  "822": {
    "id": 822,
    "name": "紫晶重甲虫 (mob_beetle)",
    "category": "4.2 野生动物与怪物",
    "subCategory": "4.溶洞·敌对精英",
    "recipe": "Lv.14 / HP:750",
    "tags": [
      "重甲",
      "掀翻"
    ],
    "value": 200,
    "desc": "正面免疫80%普通伤害，需用爆破冲击镐敲击或用弹簧垫把它掀翻暴打",
    "color1": "#5A189A",
    "color2": "#C77DFF",
    "shape": "mob_crab"
  },
  "823": {
    "id": 823,
    "name": "彩虹陆行鸟 (mob_chocobo)",
    "category": "4.2 野生动物与怪物",
    "subCategory": "5.绿洲·温顺坐骑",
    "recipe": "Lv.10 / HP:400",
    "tags": [
      "高速坐骑",
      "双人"
    ],
    "value": 90,
    "desc": "先用蜂蜜罐粘住脚再喂3个黄金小麦即可驯服为+60%移速坐骑",
    "color1": "#FFBE0B",
    "color2": "#06D6A0",
    "shape": "mob_bird"
  },
  "824": {
    "id": 824,
    "name": "滚石穿山甲 (mob_pangolin)",
    "category": "4.2 野生动物与怪物",
    "subCategory": "5.绿洲·淘气精英",
    "recipe": "Lv.13 / HP:600",
    "tags": [
      "翻滚",
      "棒球反弹"
    ],
    "value": 180,
    "desc": "缩成圆石球高速滚来，玩家挥动【充气玩具大锤】可像打棒球一样反抽回去",
    "color1": "#8D5B4C",
    "color2": "#BDC3C7",
    "shape": "mob_boar"
  },
  "825": {
    "id": 825,
    "name": "黄金毒尾蝎 (mob_scorpion)",
    "category": "4.2 野生动物与怪物",
    "subCategory": "5.绿洲·敌对狩猎",
    "recipe": "Lv.15 / HP:680",
    "tags": [
      "潜沙",
      "毒针"
    ],
    "value": 210,
    "desc": "潜伏沙丘下钻出毒刺，引水淹没沙地可逼其现形",
    "color1": "#F39C12",
    "color2": "#D90429",
    "shape": "mob_crab"
  },
  "826": {
    "id": 826,
    "name": "逃跑姜饼小人 (mob_ginger)",
    "category": "4.2 野生动物与怪物",
    "subCategory": "6.甜点·淘气宝怪",
    "recipe": "Lv.12 / HP:250",
    "tags": [
      "极速",
      "掉糖果"
    ],
    "value": 250,
    "desc": "边跑边掉满地糖果，需队友用飞索钩爪钩回来否则钻进糖果屋消失",
    "color1": "#C68B59",
    "color2": "#FFFFFF",
    "shape": "char_chef"
  },
  "827": {
    "id": 827,
    "name": "焦糖布丁法师 (mob_pudding)",
    "category": "4.2 野生动物与怪物",
    "subCategory": "6.甜点·敌对狩猎",
    "recipe": "Lv.16 / HP:720",
    "tags": [
      "远程减速",
      "治疗"
    ],
    "value": 230,
    "desc": "发射粘性焦糖球困住玩家并为果冻怪加血",
    "color1": "#F4A261",
    "color2": "#6F4E37",
    "shape": "mob_slime"
  },
  "828": {
    "id": 828,
    "name": "巧克力盾卫 (mob_choco)",
    "category": "4.2 野生动物与怪物",
    "subCategory": "6.甜点·敌对精英",
    "recipe": "Lv.18 / HP:1100",
    "tags": [
      "重盾",
      "遇火融化"
    ],
    "value": 320,
    "desc": "用火椒或火把攻击它，它的巧克力护甲会融化变成满地加速巧克力浆",
    "color1": "#3E2723",
    "color2": "#D4A373",
    "shape": "char_tinkerer"
  },
  "829": {
    "id": 829,
    "name": "浮空云魔鬼鱼 (mob_manta)",
    "category": "4.2 野生动物与怪物",
    "subCategory": "7.云海·温顺可乘",
    "recipe": "Lv.15 / HP:500",
    "tags": [
      "浮空滑翔",
      "跨岛"
    ],
    "value": 150,
    "desc": "在云岛之间虚空滑翔，玩家可直接跳到它宽大背上搭顺风车跨岛",
    "color1": "#90E0EF",
    "color2": "#FFFFFF",
    "shape": "mob_bat"
  },
  "830": {
    "id": 830,
    "name": "竖琴风精鸟 (mob_harpy)",
    "category": "4.2 野生动物与怪物",
    "subCategory": "7.云海·淘气互动",
    "recipe": "Lv.19 / HP:850",
    "tags": [
      "吹风",
      "对弹送礼"
    ],
    "value": 350,
    "desc": "吹风推人下悬崖；若玩家拿出乐器跟它合奏，它会害羞地送出星辰碎片",
    "color1": "#FFD166",
    "color2": "#FFFFFF",
    "shape": "mob_bird"
  },
  "831": {
    "id": 831,
    "name": "雷云闪电球 (mob_thunder)",
    "category": "4.2 野生动物与怪物",
    "subCategory": "7.云海·敌对狩猎",
    "recipe": "Lv.21 / HP:950",
    "tags": [
      "放电",
      "导电"
    ],
    "value": 400,
    "desc": "空中放电链接金属物；戴【引雷铁锅头盔】的队友可吸收闪电转攻速",
    "color1": "#4CC9F0",
    "color2": "#FFBE0B",
    "shape": "mob_slime"
  },
  "832": {
    "id": 832,
    "name": "发条伪装宝箱 (mob_mimic)",
    "category": "4.2 野生动物与怪物",
    "subCategory": "8.遗迹·淘气陷阱",
    "recipe": "Lv.20 / HP:900",
    "tags": [
      "伪装",
      "吞炸弹"
    ],
    "value": 450,
    "desc": "混在真宝箱里咬人；喂它吃【定时痒痒炸弹果】可直接炸开肚子爆金装",
    "color1": "#D4AC0D",
    "color2": "#3E2723",
    "shape": "chest"
  },
  "833": {
    "id": 833,
    "name": "熔炉赤焰火灵 (mob_lava)",
    "category": "4.2 野生动物与怪物",
    "subCategory": "8.遗迹·敌对狩猎",
    "recipe": "Lv.23 / HP:1200",
    "tags": [
      "烈火",
      "遇水固化"
    ],
    "value": 500,
    "desc": "全身烈火；队友用【泡泡水枪】或引水浇它可直接秒杀护盾化为黑曜石",
    "color1": "#D90429",
    "color2": "#FFBE0B",
    "shape": "mob_slime"
  },
  "834": {
    "id": 834,
    "name": "远古发条重骑 (mob_knight)",
    "category": "4.2 野生动物与怪物",
    "subCategory": "8.遗迹·敌对精英",
    "recipe": "Lv.25 / HP:1800",
    "tags": [
      "发条钥匙",
      "背刺"
    ],
    "value": 700,
    "desc": "1人正面吸引，队友用【飞索钩爪】勾住它背后的金钥匙拔下使其断电瘫痪",
    "color1": "#E09F3E",
    "color2": "#5C677D",
    "shape": "char_explorer"
  },
  "851": {
    "id": 851,
    "name": "【草甸Boss】果冻国王·波波大帝",
    "category": "4.3 八大世界Boss",
    "subCategory": "Lv.5 / HP:2,500",
    "recipe": "祭品:皇家十倍甜莓布丁",
    "tags": [
      "Boss",
      "投弹喂食破防"
    ],
    "value": 800,
    "desc": "P3张巨口吸气时，点燃【定时痒痒炸弹果】顺吸力扔进嘴里直接炸翻眩晕6秒",
    "color1": "#FF595E",
    "color2": "#FFD166",
    "shape": "boss_slime"
  },
  "852": {
    "id": 852,
    "name": "【河谷Boss】机甲河狸·大坝粉碎者",
    "category": "4.3 八大世界Boss",
    "subCategory": "Lv.10 / HP:4,800",
    "recipe": "祭品:黄金香脆松木图腾",
    "tags": [
      "Boss",
      "开闸放水冲坝"
    ],
    "value": 1600,
    "desc": "躲在木坝后发迫击炮时，拉下上游【电动拦水闸门】放洪水冲垮木坝使其短路瘫痪",
    "color1": "#8D5B4C",
    "color2": "#ADB5BD",
    "shape": "boss_beaver"
  },
  "853": {
    "id": 853,
    "name": "【绯樱Boss】千年垂枝妖狐·绯月",
    "category": "4.3 八大世界Boss",
    "subCategory": "Lv.14 / HP:7,500",
    "recipe": "祭品:绯月千年祈愿御币",
    "tags": [
      "Boss",
      "乐团奏乐破隐"
    ],
    "value": 2800,
    "desc": "化作4道分身蓄力时，吹响【黄金凯旋小号】或八音盒电路声波震碎假分身定住真身",
    "color1": "#FF758F",
    "color2": "#FFE5EC",
    "shape": "boss_kitsune"
  },
  "854": {
    "id": 854,
    "name": "【溶洞Boss】深渊晶甲巨蟹·克拉肯",
    "category": "4.3 八大世界Boss",
    "subCategory": "Lv.18 / HP:11,000",
    "recipe": "祭品:共鸣深渊紫晶核",
    "tags": [
      "Boss",
      "冰面溜蟹撞墙"
    ],
    "value": 4200,
    "desc": "在祭坛周围铺【镜面极滑冰砖】与【黑曜石防爆墙】，引巨蟹上冰打滑撞墙震碎紫晶壳",
    "color1": "#7209B7",
    "color2": "#4CC9F0",
    "shape": "boss_crab"
  },
  "855": {
    "id": 855,
    "name": "【绿洲Boss】黄金沙暴法老蝎",
    "category": "4.3 八大世界Boss",
    "subCategory": "Lv.21 / HP:15,000",
    "recipe": "祭品:太阳神金甲虫圣杯",
    "tags": [
      "Boss",
      "多人拔河拽出"
    ],
    "value": 6000,
    "desc": "钻入沙地只露毒尾时，2~4名玩家同时抛【灵巧飞索钩爪】勾住尾针合力拔出沙面",
    "color1": "#F39C12",
    "color2": "#D90429",
    "shape": "boss_scorpion"
  },
  "856": {
    "id": 856,
    "name": "【甜点Boss】暴食翻糖姜饼巨魔",
    "category": "4.3 八大世界Boss",
    "subCategory": "Lv.24 / HP:20,000",
    "recipe": "祭品:皇家焦糖彩虹姜饼屋",
    "tags": [
      "Boss",
      "蹦床反弹/投喂"
    ],
    "value": 8500,
    "desc": "铺【高弹果冻蹦床砖】反弹巨型糖球砸脸，或端一锅加变身菇的【黑暗料理】喂它变肥鸡",
    "color1": "#C68B59",
    "color2": "#FF99C8",
    "shape": "boss_ginger"
  },
  "857": {
    "id": 857,
    "name": "【云海Boss】星穹幻彩云鲸",
    "category": "4.3 八大世界Boss",
    "subCategory": "Lv.27 / HP:26,000",
    "recipe": "祭品:星穹唤鲸八音海螺",
    "tags": [
      "Boss",
      "飞艇登背敲晶"
    ],
    "value": 12000,
    "desc": "全队驾驶【八人云海探险飞艇】或4人叠罗汉跳上云鲸背脊，敲碎3颗寄生雷晶净化它",
    "color1": "#00BBF9",
    "color2": "#FFD166",
    "shape": "boss_whale"
  },
  "858": {
    "id": 858,
    "name": "【终极Boss】发条时间巨像·克洛诺斯",
    "category": "4.3 八大世界Boss",
    "subCategory": "Lv.30 / HP:38,000",
    "recipe": "祭品:古老黄金上弦发条钥",
    "tags": [
      "Boss",
      "四色电路破盾"
    ],
    "value": 25000,
    "desc": "开启时间回溯护盾时，4人分工踩四角压力板接通四色魔能电路激活中央脉冲塔破盾",
    "color1": "#FFB703",
    "color2": "#2C223E",
    "shape": "boss_colossus"
  }
};
