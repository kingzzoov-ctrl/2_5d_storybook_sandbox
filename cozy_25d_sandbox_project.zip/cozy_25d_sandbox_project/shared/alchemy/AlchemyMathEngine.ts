// LLM Procedural Alchemy Schema + 5-Step Deterministic Math Stat Algorithm
export interface LLMAlchemyOutputSchema {
  item_name: string;
  lore_description: string;
  item_category: 'WEAPON_MELEE' | 'WEAPON_RANGED' | 'WEAPON_STAFF' | 'PRANK_TOY' | 'CONSUMABLE' | 'WEARABLE_HAT' | 'TRAP_GADGET';
  primary_mechanic: string;
  logic_synergy_score: number; // 0.80 ~ 1.50
  stat_weights: { atk_weight: number; def_weight: number; impulse_weight: number; utility_weight: number };
  visual_style: { primary_color_hex: string; secondary_color_hex: string; particle_aura: string };
}

export function computeAlchemyItemStats(values: number[], logicScore: number, profLevel: number, hasDew: boolean, randEps: number, weights: LLMAlchemyOutputSchema['stat_weights']) {
  const k = values.length;
  const meanPow = values.reduce((acc, v) => acc + Math.pow(v, 1.35), 0) / k;
  const tEff = Math.pow(meanPow, 1 / 1.35) * (1 + 0.12 * (k - 1));
  const dewBonus = hasDew ? 0.15 : 0;
  const Q = logicScore * (1 + 0.02 * profLevel + dewBonus) * randEps;
  const rarityTier = Q >= 1.55 ? 3 : Q >= 1.25 ? 2 : Q >= 1.0 ? 1 : 0;
  const budget = Math.round(8.5 * Math.pow(tEff, 0.82) * Q);
  return {
    tEff: Number(tEff.toFixed(1)),
    qualityScore: Number(Q.toFixed(2)),
    rarityTier,
    atk: Math.round(budget * weights.atk_weight * 1.2),
    def: Math.round(budget * weights.def_weight * 0.6),
    hp: Math.round(budget * weights.def_weight * 2.5),
    impulse: Number((3.0 + budget * weights.impulse_weight * 0.15).toFixed(1)),
    utilityPct: Math.min(50, Math.round(budget * weights.utility_weight * 0.4))
  };
}
